#!/usr/bin/env python3
"""Reproduce the published numerical summaries from the public stripped tables.

The script uses only Python's standard library. It deliberately makes no network
requests and never calls a model, clones a repository, or invokes an evaluator.
"""
from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
import random
import statistics
from typing import Any

MODELS = ("openai/gpt-6.1-sol", "anthropic/claude-sonnet-5.5")
BOOTSTRAP_SAMPLES = 2000
BOOTSTRAP_SEED = 20261022


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def quantile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    index = (len(ordered) - 1) * probability
    lower = int(index)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = index - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def bootstrap(issue_metrics: dict[str, dict[str, float]]) -> dict[str, Any]:
    issue_ids = sorted(issue_metrics)
    rng = random.Random(BOOTSTRAP_SEED)
    samples: dict[str, list[float]] = {"initial_pass_rate": [], "final_pass_rate": [], "review_uplift": []}
    for _ in range(BOOTSTRAP_SAMPLES):
        draw = [rng.choice(issue_ids) for _ in issue_ids]
        for metric, values in samples.items():
            values.append(statistics.fmean(issue_metrics[item][metric] for item in draw))
    return {
        "cluster": "issue",
        "samples": BOOTSTRAP_SAMPLES,
        "seed": BOOTSTRAP_SEED,
        "confidence_level": 0.95,
        "intervals": {
            metric: {"low": quantile(values, 0.025), "high": quantile(values, 0.975)}
            for metric, values in samples.items()
        },
    }


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def compute(data_dir: Path) -> dict[str, Any]:
    workflows = read_csv(data_dir / "v8_workflows.csv")
    tasks = read_csv(data_dir / "tasks.csv")
    events = read_csv(data_dir / "api_events_sanitized.csv")
    reservations = read_csv(data_dir / "reservations_sanitized.csv")
    run_summary = json.loads((data_dir / "v8_run_summary.json").read_text(encoding="utf-8"))

    require(len(workflows) == 48, "Expected exactly 48 workflow rows")
    require(len(tasks) == 12, "Expected exactly 12 task rows")
    task_ids = {row["issue_id"] for row in tasks}
    require(len(task_ids) == 12, "Task identifiers must be unique")

    seen: set[tuple[str, str, str, str]] = set()
    by_issue: dict[str, list[dict[str, str]]] = defaultdict(list)
    by_pair: dict[tuple[str, str], list[dict[str, str]]] = defaultdict(list)
    transitions: Counter[tuple[str, str]] = Counter()
    completed_rows: list[dict[str, str]] = []

    for row in workflows:
        required = {
            "issue_id", "author_model", "reviewer_model", "replicate", "completion_status",
            "initial_outcome", "final_outcome", "termination_type", "termination_detail_code",
            "author_turn_count", "author_compacted_turn_count", "dropped_tool_cycles",
        }
        require(required.issubset(row), f"Workflow row has missing fields: {required - set(row)}")
        author, reviewer = row["author_model"], row["reviewer_model"]
        require(author in MODELS and reviewer in MODELS and author != reviewer, "Unexpected directed model pair")
        require(row["issue_id"] in task_ids, "Workflow refers to an unknown task")
        require(row["replicate"] in {"1", "2"}, "Replicate must be 1 or 2")
        key = (row["issue_id"], author, reviewer, row["replicate"])
        require(key not in seen, f"Duplicate workflow key: {key}")
        seen.add(key)
        by_issue[row["issue_id"]].append(row)
        by_pair[(author, reviewer)].append(row)
        completed = row["completion_status"] == "completed"
        if completed:
            require(row["initial_outcome"] in {"pass", "fail"} and row["final_outcome"] in {"pass", "fail"}, "Completed row must have pass/fail outcomes")
            require(not row["termination_type"] and not row["termination_detail_code"], "Completed row cannot have termination fields")
            completed_rows.append(row)
            transitions[(row["initial_outcome"], row["final_outcome"])] += 1
        else:
            require(row["completion_status"] == "terminated_before_complete_workflow", "Unknown completion status")
            require(row["initial_outcome"] == "not_evaluated_due_to_termination" and row["final_outcome"] == "not_evaluated_due_to_termination", "Terminated row must have missing evaluator outcomes")
            require(row["termination_type"] and row["termination_detail_code"], "Terminated row requires a public termination code")

    require(set(by_issue) == task_ids and all(len(rows) == 4 for rows in by_issue.values()), "Expected four rows per issue")
    expected_pairs = {(MODELS[0], MODELS[1]), (MODELS[1], MODELS[0])}
    require(set(by_pair) == expected_pairs and all(len(rows) == 24 for rows in by_pair.values()), "Expected 24 rows per directed pair")

    planned = len(workflows)
    completed = len(completed_rows)
    terminated = planned - completed
    initial_passes = sum(row["initial_outcome"] == "pass" for row in workflows)
    final_passes = sum(row["final_outcome"] == "pass" for row in workflows)
    completed_initial_passes = sum(row["initial_outcome"] == "pass" for row in completed_rows)
    completed_final_passes = sum(row["final_outcome"] == "pass" for row in completed_rows)

    issue_metrics: dict[str, dict[str, float]] = {}
    issue_rows: list[dict[str, Any]] = []
    for issue_id in sorted(by_issue):
        rows = by_issue[issue_id]
        initial_rate = sum(row["initial_outcome"] == "pass" for row in rows) / len(rows)
        final_rate = sum(row["final_outcome"] == "pass" for row in rows) / len(rows)
        issue_metrics[issue_id] = {
            "initial_pass_rate": initial_rate,
            "final_pass_rate": final_rate,
            "review_uplift": final_rate - initial_rate,
        }
        issue_rows.append({
            "issue_id": issue_id,
            "planned": len(rows),
            "completed": sum(row["completion_status"] == "completed" for row in rows),
            "terminated": sum(row["completion_status"] != "completed" for row in rows),
            "initial_passes": sum(row["initial_outcome"] == "pass" for row in rows),
            "final_passes": sum(row["final_outcome"] == "pass" for row in rows),
        })

    pair_rows: list[dict[str, Any]] = []
    for author, reviewer in ((MODELS[0], MODELS[1]), (MODELS[1], MODELS[0])):
        rows = by_pair[(author, reviewer)]
        pair_rows.append({
            "author_model": author,
            "reviewer_model": reviewer,
            "planned": len(rows),
            "completed": sum(row["completion_status"] == "completed" for row in rows),
            "terminated": sum(row["completion_status"] != "completed" for row in rows),
            "initial_passes": sum(row["initial_outcome"] == "pass" for row in rows),
            "final_passes": sum(row["final_outcome"] == "pass" for row in rows),
        })

    termination_types = Counter(row["termination_type"] for row in workflows if row["completion_status"] != "completed")
    termination_details = Counter(row["termination_detail_code"] for row in workflows if row["completion_status"] != "completed")
    author_turns = sum(int(row["author_turn_count"]) for row in workflows)
    compacted_turns = sum(int(row["author_compacted_turn_count"]) for row in workflows)
    dropped_cycles = sum(int(row["dropped_tool_cycles"]) for row in workflows)

    settled_events = [event for event in events if event["event_status"] == "settled"]
    unknown_events = [event for event in events if event["event_status"] == "unknown_transport"]
    require(len(events) == 564 and len(settled_events) == 562 and len(unknown_events) == 2, "Unexpected API event counts")
    event_cost = sum(float(event["settled_cost_usd"]) for event in settled_events)
    reservation_total = sum(float(row["estimated_usd"]) for row in reservations)

    task_language_counts = Counter(row["language"] for row in tasks)
    task_input_counts = Counter(row["input_form"] for row in tasks)
    task_validation_counts = Counter(int(row["archived_check_count"]) for row in tasks)

    planned_initial_rate = initial_passes / planned
    planned_final_rate = final_passes / planned
    completed_initial_rate = completed_initial_passes / completed
    completed_final_rate = completed_final_passes / completed
    incidence = sum(any(row["final_outcome"] == "pass" for row in rows) for rows in by_issue.values())

    result = {
        "schema": "autonomous-code-review-study/paper-numbers/v1",
        "design": {
            "tasks": len(tasks),
            "planned_workflows": planned,
            "directed_pairs": 2,
            "replicates_per_task_pair": 2,
            "models": list(MODELS),
            "languages": dict(sorted(task_language_counts.items())),
            "input_forms": dict(sorted(task_input_counts.items())),
            "prior_exposure": "V3-V7",
        },
        "outcomes": {
            "completed_workflows": completed,
            "terminated_workflows": terminated,
            "planned_matrix": {
                "initial_passes": initial_passes,
                "final_passes": final_passes,
                "initial_pass_rate": planned_initial_rate,
                "final_pass_rate": planned_final_rate,
                "review_uplift": planned_final_rate - planned_initial_rate,
            },
            "completed_case": {
                "initial_passes": completed_initial_passes,
                "final_passes": completed_final_passes,
                "initial_pass_rate": completed_initial_rate,
                "final_pass_rate": completed_final_rate,
                "review_uplift": completed_final_rate - completed_initial_rate,
            },
            "paired_transitions_completed": {
                "pass_to_pass": transitions[("pass", "pass")],
                "pass_to_fail": transitions[("pass", "fail")],
                "fail_to_pass": transitions[("fail", "pass")],
                "fail_to_fail": transitions[("fail", "fail")],
            },
            "issue_weighted_planned_matrix": {
                "initial_pass_rate": statistics.fmean(item["initial_pass_rate"] for item in issue_metrics.values()),
                "final_pass_rate": statistics.fmean(item["final_pass_rate"] for item in issue_metrics.values()),
                "review_uplift": statistics.fmean(item["review_uplift"] for item in issue_metrics.values()),
            },
            "issues_with_at_least_one_final_pass": incidence,
            "issues_with_at_least_one_final_pass_rate": incidence / len(by_issue),
        },
        "directed_pairs": pair_rows,
        "issues": issue_rows,
        "issue_cluster_bootstrap": bootstrap(issue_metrics),
        "termination_summary": {
            "by_type": dict(sorted(termination_types.items())),
            "by_detail_code": dict(sorted(termination_details.items())),
        },
        "agent_operational_summary": {
            "author_turns": author_turns,
            "author_compacted_turns": compacted_turns,
            "dropped_tool_cycles": dropped_cycles,
        },
        "api_accounting": {
            "matrix_event_records": len(events),
            "settled_responses": len(settled_events),
            "unknown_transport_events": len(unknown_events),
            "matrix_settled_cost_usd": event_cost,
            "event_roles": dict(sorted(Counter(event["role"] for event in events).items())),
            "lifetime_actual_usd": run_summary["api_accounting"]["lifetime_actual_usd"],
            "lifetime_open_reservations_usd": run_summary["api_accounting"]["lifetime_open_reservations_usd"],
            "hard_cap_usd": run_summary["api_accounting"]["hard_cap_usd"],
            "remaining_headroom_after_reservations_usd": run_summary["api_accounting"]["remaining_headroom_after_reservations_usd"],
            "reservations_rows": len(reservations),
            "reservations_total_usd": reservation_total,
            "reservations_by_origin": {
                origin: sum(float(row["estimated_usd"]) for row in reservations if row["origin"] == origin)
                for origin in sorted({row["origin"] for row in reservations})
            },
        },
        "task_validation_summary": {
            "tasks_with_archived_C0_fail_historical_fix_pass": sum(
                row["c0_check"] == "validated_fail_C0_pass_historical_fix" and row["historical_fix_check"] == "validated_fail_C0_pass_historical_fix"
                for row in tasks
            ),
            "archived_check_count_distribution": {str(key): value for key, value in sorted(task_validation_counts.items())},
        },
    }

    expected_integrity = run_summary["result_integrity"]
    require(result["outcomes"]["completed_workflows"] == expected_integrity["completed_workflows"], "Completion total disagrees with public summary")
    require(result["outcomes"]["terminated_workflows"] == expected_integrity["terminated_workflows"], "Termination total disagrees with public summary")
    require(result["outcomes"]["planned_matrix"]["final_pass_rate"] == expected_integrity["issue_weighted_pass_rate"], "Planned pass rate disagrees with public summary")
    require(result["outcomes"]["planned_matrix"]["review_uplift"] == expected_integrity["review_uplift"], "Uplift disagrees with public summary")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True, help="Directory containing stripped public CSV/JSON tables")
    parser.add_argument("--output", type=Path, required=True, help="Derived JSON output path")
    parser.add_argument("--check", type=Path, help="Golden expected JSON; fail if derived output differs")
    args = parser.parse_args()
    try:
        result = compute(args.data)
        if args.check:
            expected = json.loads(args.check.read_text(encoding="utf-8"))
            require(result == expected, "Derived paper numbers differ from the supplied expected JSON")
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(f"Wrote {args.output}")
        if args.check:
            print("PASS: derived numbers match expected/paper_numbers.json")
        return 0
    except (OSError, ValueError, csv.Error, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
