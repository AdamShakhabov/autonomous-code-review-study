#!/usr/bin/env python3
"""Reproduce numerical summaries from the public, content-reduced tables.

Uses only Python's standard library. Makes no network requests and never calls
models, clones repositories, or invokes hidden evaluators.
"""
from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
import random
import statistics
from typing import Any

MODELS = ("openai/gpt-6.1-sol", "anthropic/claude-sonnet-5.5")
BOOTSTRAP_SAMPLES = 2000
BOOTSTRAP_SEED = 20261022


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def quantile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    index = (len(ordered) - 1) * probability
    lower = int(index)
    upper = min(lower + 1, len(ordered) - 1)
    fraction = index - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def bootstrap(issue_metrics: dict[str, dict[str, float]]) -> dict[str, Any]:
    """Resample issues; completed-case uplift interval is diagnostic only."""
    issue_ids = sorted(issue_metrics)
    rng = random.Random(BOOTSTRAP_SEED)
    metric_names = (
        "planned_final_pass_rate",
        "completed_initial_pass_rate",
        "completed_final_pass_rate",
        "completed_review_uplift",
    )
    samples: dict[str, list[float]] = {metric: [] for metric in metric_names}
    for _ in range(BOOTSTRAP_SAMPLES):
        draw = [rng.choice(issue_ids) for _ in issue_ids]
        for metric, values in samples.items():
            values.append(statistics.fmean(issue_metrics[item][metric] for item in draw))
    intervals = {
        metric: {"low": quantile(values, 0.025), "high": quantile(values, 0.975)}
        for metric, values in samples.items()
    }
    return {
        "cluster": "issue",
        "samples": BOOTSTRAP_SAMPLES,
        "seed": BOOTSTRAP_SEED,
        "confidence_level": 0.95,
        "intervals": intervals,
        "completed_review_uplift_interpretation": (
            "diagnostic_only; a degenerate interval caused by zero observed within-issue transitions "
            "is not a population-effect uncertainty interval"
        ),
    }


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def compute(data_dir: Path) -> dict[str, Any]:
    workflows = read_csv(data_dir / "v8_workflows.csv")
    tasks = read_csv(data_dir / "tasks.csv")
    events = read_csv(data_dir / "api_events_sanitized.csv")
    reservations = read_csv(data_dir / "reservations_sanitized.csv")
    run_summary = json.loads((data_dir / "v8_run_summary.json").read_text(encoding="utf-8"))

    require(len(workflows) == 48, "Expected exactly 48 workflow rows")
    require(len(tasks) == 12, "Expected exactly 12 task rows")
    tasks_by_issue = {row["issue_id"]: row for row in tasks}
    task_ids = set(tasks_by_issue)
    require(len(task_ids) == 12, "Task identifiers must be unique")

    seen: set[tuple[str, str, str, str]] = set()
    by_issue: dict[str, list[dict[str, str]]] = defaultdict(list)
    by_pair: dict[tuple[str, str], list[dict[str, str]]] = defaultdict(list)
    transitions: Counter[tuple[str, str]] = Counter()
    completed_rows: list[dict[str, str]] = []

    for row in workflows:
        required = {
            "issue_id", "author_model", "reviewer_model", "replicate", "completion_status",
            "initial_outcome", "final_outcome", "termination_type", "termination_detail_code",
            "author_turn_count", "author_compacted_turn_count", "dropped_tool_cycles",
        }
        require(required.issubset(row), f"Workflow row has missing fields: {required - set(row)}")
        author, reviewer = row["author_model"], row["reviewer_model"]
        require(author in MODELS and reviewer in MODELS and author != reviewer, "Unexpected directed model pair")
        require(row["issue_id"] in task_ids, "Workflow refers to an unknown task")
        require(row["replicate"] in {"1", "2"}, "Replicate must be 1 or 2")
        key = (row["issue_id"], author, reviewer, row["replicate"])
        require(key not in seen, f"Duplicate workflow key: {key}")
        seen.add(key)
        by_issue[row["issue_id"]].append(row)
        by_pair[(author, reviewer)].append(row)
        completed = row["completion_status"] == "completed"
        if completed:
            require(row["initial_outcome"] in {"pass", "fail"} and row["final_outcome"] in {"pass", "fail"}, "Completed row must have pass/fail outcomes")
            require(not row["termination_type"] and not row["termination_detail_code"], "Completed row cannot have termination fields")
            completed_rows.append(row)
            transitions[(row["initial_outcome"], row["final_outcome"])] += 1
        else:
            require(row["completion_status"] == "terminated_before_complete_workflow", "Unknown completion status")
            require(row["initial_outcome"] in {
                "initial_evaluator_ran_result_not_persisted",
                "not_evaluated_before_initial_evaluation",
            }, "Terminated row must distinguish missing initial outcomes")
            require(row["final_outcome"] == "not_evaluated_due_to_termination", "Terminated row must have no final evaluator outcome")
            require(row["termination_type"] and row["termination_detail_code"], "Terminated row requires a public termination code")

    require(set(by_issue) == task_ids and all(len(rows) == 4 for rows in by_issue.values()), "Expected four rows per issue")
    expected_pairs = {(MODELS[0], MODELS[1]), (MODELS[1], MODELS[0])}
    require(set(by_pair) == expected_pairs and all(len(rows) == 24 for rows in by_pair.values()), "Expected 24 rows per directed pair")

    planned = len(workflows)
    completed = len(completed_rows)
    terminated = planned - completed
    completed_initial_passes = sum(row["initial_outcome"] == "pass" for row in completed_rows)
    completed_final_passes = sum(row["final_outcome"] == "pass" for row in completed_rows)
    planned_final_passes = sum(row["final_outcome"] == "pass" for row in workflows)
    initial_not_persisted = sum(row["initial_outcome"] == "initial_evaluator_ran_result_not_persisted" for row in workflows)
    initial_not_run = sum(row["initial_outcome"] == "not_evaluated_before_initial_evaluation" for row in workflows)

    issue_metrics: dict[str, dict[str, float]] = {}
    issue_rows: list[dict[str, Any]] = []
    for issue_id in sorted(by_issue):
        rows = by_issue[issue_id]
        completed_issue_rows = [row for row in rows if row["completion_status"] == "completed"]
        require(bool(completed_issue_rows), f"Issue has no completed workflow: {issue_id}")
        completed_initial_rate = sum(row["initial_outcome"] == "pass" for row in completed_issue_rows) / len(completed_issue_rows)
        completed_final_rate = sum(row["final_outcome"] == "pass" for row in completed_issue_rows) / len(completed_issue_rows)
        planned_final_rate = sum(row["final_outcome"] == "pass" for row in rows) / len(rows)
        issue_metrics[issue_id] = {
            "planned_final_pass_rate": planned_final_rate,
            "completed_initial_pass_rate": completed_initial_rate,
            "completed_final_pass_rate": completed_final_rate,
            "completed_review_uplift": completed_final_rate - completed_initial_rate,
        }
        issue_rows.append({
            "issue_id": issue_id,
            "planned": len(rows),
            "completed": len(completed_issue_rows),
            "terminated": len(rows) - len(completed_issue_rows),
            "initial_passes_completed": sum(row["initial_outcome"] == "pass" for row in completed_issue_rows),
            "final_passes_planned": sum(row["final_outcome"] == "pass" for row in rows),
            "initial_result_not_persisted": sum(row["initial_outcome"] == "initial_evaluator_ran_result_not_persisted" for row in rows),
            "initial_evaluation_not_run": sum(row["initial_outcome"] == "not_evaluated_before_initial_evaluation" for row in rows),
        })

    pair_rows: list[dict[str, Any]] = []
    for author, reviewer in ((MODELS[0], MODELS[1]), (MODELS[1], MODELS[0])):
        rows = by_pair[(author, reviewer)]
        completed_pair = [row for row in rows if row["completion_status"] == "completed"]
        pair_rows.append({
            "author_model": author,
            "reviewer_model": reviewer,
            "planned": len(rows),
            "completed": len(completed_pair),
            "terminated": len(rows) - len(completed_pair),
            "initial_passes_completed": sum(row["initial_outcome"] == "pass" for row in completed_pair),
            "final_passes_completed": sum(row["final_outcome"] == "pass" for row in completed_pair),
            "final_passes_planned": sum(row["final_outcome"] == "pass" for row in rows),
            "initial_result_not_persisted": sum(row["initial_outcome"] == "initial_evaluator_ran_result_not_persisted" for row in rows),
            "initial_evaluation_not_run": sum(row["initial_outcome"] == "not_evaluated_before_initial_evaluation" for row in rows),
        })

    input_form_summary: dict[str, dict[str, Any]] = {}
    task_input_counts = Counter(row["input_form"] for row in tasks)
    for input_form in sorted(task_input_counts):
        form_rows = [row for row in workflows if tasks_by_issue[row["issue_id"]]["input_form"] == input_form]
        form_completed = [row for row in form_rows if row["completion_status"] == "completed"]
        input_form_summary[input_form] = {
            "tasks": sum(row["input_form"] == input_form for row in tasks),
            "planned_workflows": len(form_rows),
            "completed_workflows": len(form_completed),
            "terminated_workflows": len(form_rows) - len(form_completed),
            "final_passes_planned": sum(row["final_outcome"] == "pass" for row in form_rows),
            "final_pass_rate_planned": sum(row["final_outcome"] == "pass" for row in form_rows) / len(form_rows),
            "final_passes_completed": sum(row["final_outcome"] == "pass" for row in form_completed),
            "final_pass_rate_completed": sum(row["final_outcome"] == "pass" for row in form_completed) / len(form_completed),
        }

    termination_rows = [row for row in workflows if row["completion_status"] != "completed"]
    termination_types = Counter(row["termination_type"] for row in termination_rows)
    termination_details = Counter(row["termination_detail_code"] for row in termination_rows)
    author_turns = sum(int(row["author_turn_count"]) for row in workflows)
    compacted_turns = sum(int(row["author_compacted_turn_count"]) for row in workflows)
    dropped_cycles = sum(int(row["dropped_tool_cycles"]) for row in workflows)

    settled_events = [event for event in events if event["event_status"] == "settled"]
    unknown_events = [event for event in events if event["event_status"] == "unknown_transport"]
    require(len(events) == 564 and len(settled_events) == 562 and len(unknown_events) == 2, "Unexpected API event counts")
    event_cost = sum(float(event["settled_cost_usd"]) for event in settled_events)
    reservation_total = sum(float(row["estimated_usd"]) for row in reservations)

    task_language_counts = Counter(row["language"] for row in tasks)
    task_validation_counts = Counter(int(row["archived_check_count"]) for row in tasks)
    planned_final_rate = planned_final_passes / planned
    completed_initial_rate = completed_initial_passes / completed
    completed_final_rate = completed_final_passes / completed
    incidence = sum(any(row["final_outcome"] == "pass" for row in rows) for rows in by_issue.values())

    result = {
        "schema": "autonomous-code-review-study/paper-numbers/v2",
        "design": {
            "tasks": len(tasks),
            "planned_workflows": planned,
            "directed_pairs": 2,
            "replicates_per_task_pair": 2,
            "models": list(MODELS),
            "languages": dict(sorted(task_language_counts.items())),
            "input_forms": dict(sorted(task_input_counts.items())),
            "prior_exposure": "V3-V7",
        },
        "outcomes": {
            "completed_workflows": completed,
            "terminated_workflows": terminated,
            "planned_matrix": {
                "final_passes": planned_final_passes,
                "final_pass_rate": planned_final_rate,
                "initial_outcome_audit": {
                    "completed_initial_results": completed,
                    "post_initial_evaluation_result_not_persisted": initial_not_persisted,
                    "initial_evaluation_not_run": initial_not_run,
                    "full_planned_initial_pass_rate": None,
                },
            },
            "completed_case": {
                "initial_passes": completed_initial_passes,
                "final_passes": completed_final_passes,
                "initial_pass_rate": completed_initial_rate,
                "final_pass_rate": completed_final_rate,
                "review_uplift": completed_final_rate - completed_initial_rate,
            },
            "paired_transitions_completed": {
                "pass_to_pass": transitions[("pass", "pass")],
                "pass_to_fail": transitions[("pass", "fail")],
                "fail_to_pass": transitions[("fail", "pass")],
                "fail_to_fail": transitions[("fail", "fail")],
            },
            "issue_weighted_planned_matrix": {
                "final_pass_rate": statistics.fmean(item["planned_final_pass_rate"] for item in issue_metrics.values()),
            },
            "issues_with_at_least_one_final_pass": incidence,
            "issues_with_at_least_one_final_pass_rate": incidence / len(by_issue),
        },
        "directed_pairs": pair_rows,
        "outcomes_by_input_form": input_form_summary,
        "issues": issue_rows,
        "issue_cluster_bootstrap": bootstrap(issue_metrics),
        "termination_summary": {
            "by_type": dict(sorted(termination_types.items())),
            "by_detail_code": dict(sorted(termination_details.items())),
        },
        "agent_operational_summary": {
            "author_turns": author_turns,
            "author_compacted_turns": compacted_turns,
            "dropped_tool_cycles": dropped_cycles,
        },
        "api_accounting": {
            "matrix_event_records": len(events),
            "settled_responses": len(settled_events),
            "unknown_transport_events": len(unknown_events),
            "matrix_settled_cost_usd": event_cost,
            "event_roles": dict(sorted(Counter(event["role"] for event in events).items())),
            "lifetime_actual_usd": run_summary["api_accounting"]["lifetime_actual_usd"],
            "lifetime_open_reservations_usd": run_summary["api_accounting"]["lifetime_open_reservations_usd"],
            "hard_cap_usd": run_summary["api_accounting"]["hard_cap_usd"],
            "remaining_headroom_after_reservations_usd": run_summary["api_accounting"]["remaining_headroom_after_reservations_usd"],
            "reservations_rows": len(reservations),
            "reservations_total_usd": reservation_total,
            "reservations_by_origin": {
                origin: sum(float(row["estimated_usd"]) for row in reservations if row["origin"] == origin)
                for origin in sorted({row["origin"] for row in reservations})
            },
        },
        "task_validation_summary": {
            "tasks_with_archived_C0_fail_historical_fix_pass": sum(
                row["c0_check"] == "validated_fail_C0_pass_historical_fix" and row["historical_fix_check"] == "validated_fail_C0_pass_historical_fix"
                for row in tasks
            ),
            "archived_check_count_distribution": {str(key): value for key, value in sorted(task_validation_counts.items())},
        },
    }

    expected_integrity = run_summary["result_integrity"]
    require(result["outcomes"]["completed_workflows"] == expected_integrity["completed_workflows"], "Completion total disagrees with public summary")
    require(result["outcomes"]["terminated_workflows"] == expected_integrity["terminated_workflows"], "Termination total disagrees with public summary")
    require(result["outcomes"]["planned_matrix"]["final_pass_rate"] == expected_integrity["issue_weighted_pass_rate"], "Planned final pass rate disagrees with public summary")
    require(result["outcomes"]["completed_case"]["review_uplift"] == expected_integrity["review_uplift"], "Completed-case uplift disagrees with public summary")
    require(initial_not_persisted == 5 and initial_not_run == 3, "Unexpected initial-evaluation audit counts")
    aggregate = json.loads((data_dir / "analysis_v8.json").read_text(encoding="utf-8"))
    require(aggregate.get("analysis_version") == 2, "Expected corrected aggregate analysis version 2")
    for field in ("outcomes", "outcomes_by_input_form", "directed_pairs", "issues", "issue_cluster_bootstrap", "termination_summary"):
        require(aggregate.get(field) == result[field], f"Corrected aggregate analysis disagrees on {field}")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True, help="Directory containing stripped public CSV/JSON tables")
    parser.add_argument("--output", type=Path, required=True, help="Derived JSON output path")
    parser.add_argument("--check", type=Path, help="Golden expected JSON; fail if derived output differs")
    args = parser.parse_args()
    try:
        result = compute(args.data)
        if args.check:
            expected = json.loads(args.check.read_text(encoding="utf-8"))
            require(result == expected, "Derived paper numbers differ from the supplied expected JSON")
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(f"Wrote {args.output}")
        if args.check:
            print("PASS: derived numbers match expected/paper_numbers.json")
        return 0
    except (OSError, ValueError, csv.Error, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
