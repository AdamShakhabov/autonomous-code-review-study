#!/usr/bin/env python3
"""Воспроизводимый драйвер экспериментального harness.

Без ``--execute`` он выполняет только валидацию JSON и закреплённых файлов; ни
OpenRouter, ни Bubblewrap, ни команда evaluator при этом не вызываются.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
import time
from typing import Any

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from pr_harness.core import (  # noqa: E402
    CostLedger,
    HarnessError,
    MODEL_IDS,
    assert_workspace_hygiene,
    atomic_write_json,
    copy_regular_tree,
    directed_pairs,
    internal_relative_symlink_map,
    load_json,
    render_snapshot_patch,
    prepare_runtime_workspace,
    runtime_spec,
    snapshot_tree,
    stage_dependencies,
    tree_sha256,
    validate_config,
    validate_issue_files,
    validate_manifest,
)
from pr_harness.evaluator import run_hidden_evaluator, stage_hidden_evaluator  # noqa: E402
from pr_harness.isolation import ToolRunner  # noqa: E402
from pr_harness.openrouter import OpenRouterClient, OpenRouterError, write_request_contract  # noqa: E402
from pr_harness.stages import (  # noqa: E402
    adjudication_json,
    adjudicator_prompts,
    author_prompts,
    parse_adjudication,
    parse_review_report,
    review_report_json,
    reviewer_prompts,
    run_agent_stage,
    ProtocolViolationError,
    StageError,
)


def _number_equal(left: Any, right: Any) -> bool:
    return (isinstance(left, (int, float)) and not isinstance(left, bool)
            and isinstance(right, (int, float)) and not isinstance(right, bool)
            and math.isfinite(left) and math.isfinite(right) and abs(float(left) - float(right)) < 1e-12)


def _forbid_secret_values(value: Any, trail: str = "config") -> None:
    """Reject accidental credential storage in config before it can be copied/logged."""
    if isinstance(value, dict):
        for key, nested in value.items():
            if not isinstance(key, str):
                raise HarnessError(f"{trail} has a non-string key")
            lowered = key.lower()
            if lowered in {"api_key", "apikey", "openrouter_api_key", "authorization_header", "bearer_token"}:
                raise HarnessError(f"{trail}.{key} must not contain a credential; use api_key_env only")
            _forbid_secret_values(nested, f"{trail}.{key}")
    elif isinstance(value, list):
        for index, nested in enumerate(value):
            _forbid_secret_values(nested, f"{trail}[{index}]")


def validate_preflight(config: dict[str, Any], authorization: dict[str, Any], model_selection: dict[str, Any]) -> None:
    """Validate that config cannot silently alter the authorised budget or model set."""
    validate_config(config)
    _forbid_secret_values(config)
    if authorization.get("currency") != "USD" or authorization.get("includes_technical_probes") is not True:
        raise HarnessError("Budget authorization is not a USD authorization including preflight probes")
    if authorization.get("article_writing") != "prohibited":
        raise HarnessError("Authorization must preserve the prohibition on article writing")
    budget = authorization.get("max_total_openrouter_usd")
    preflight = authorization.get("known_preflight_spend_usd")
    if not _number_equal(config.get("max_total_usd"), budget):
        raise HarnessError("config.max_total_usd must equal the authorised OpenRouter ceiling exactly")
    if not _number_equal(config.get("known_preflight_spend_usd"), preflight):
        raise HarnessError("config.known_preflight_spend_usd must equal authorised known preflight spend exactly")
    if not isinstance(preflight, (int, float)) or isinstance(preflight, bool) or preflight < 0 or preflight > budget:
        raise HarnessError("Budget authorization contains an invalid preflight spend")
    selected = model_selection.get("models")
    if not isinstance(selected, dict):
        raise HarnessError("Model selection lacks models")
    selected_ids = {name: item.get("id") for name, item in selected.items() if isinstance(item, dict)}
    configured_ids = [item["id"] for item in config["models"]]
    if (len(configured_ids) not in {2, 3} or len(set(configured_ids)) != len(configured_ids)
            or set(selected_ids.values()) != set(configured_ids)
            or set(selected_ids) != {model_id.split("/", 1)[0] for model_id in configured_ids}):
        raise HarnessError("Preflight model selection and configured provider/model set do not match exactly")
    if configured_ids != list(selected_ids.values()):
        raise HarnessError("config.models order must match the frozen model-selection record")
    transport = config.get("openrouter")
    if not isinstance(transport, dict):
        raise HarnessError("config.openrouter is required")
    allowed_transport = {"api_key_env", "timeout_seconds"}
    if set(transport) != allowed_transport:
        raise HarnessError("config.openrouter may contain only api_key_env and timeout_seconds")
    if not isinstance(transport["api_key_env"], str) or not transport["api_key_env"]:
        raise HarnessError("config.openrouter.api_key_env must be a non-empty name")
    if not isinstance(transport["timeout_seconds"], int) or not 1 <= transport["timeout_seconds"] <= 600:
        raise HarnessError("config.openrouter.timeout_seconds must be an integer from 1 to 600")


def validate_inputs(config_path: Path, manifest_path: Path, authorization_path: Path, model_selection_path: Path) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    config = load_json(config_path)
    manifest = load_json(manifest_path)
    authorization = load_json(authorization_path)
    model_selection = load_json(model_selection_path)
    validate_preflight(config, authorization, model_selection)
    validate_manifest(manifest)
    # File-hash verification is read-only and must complete before any possible
    # network request.  It also establishes that evaluator paths do not overlap C0.
    for issue in manifest["issues"]:
        validate_issue_files(issue)
    return config, manifest, authorization


def _safe_component(value: str) -> str:
    return value.replace("/", "__").replace(".", "_")


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="")


MAX_VISIBLE_DIFF_UTF8_BYTES = 6_000


def _bounded_prompt_text(text: str, maximum_utf8_bytes: int) -> tuple[str, dict[str, Any]]:
    """Deterministically retain a UTF-8-safe diff prefix under the frozen prompt cap.

    The complete diff remains in the run artefact.  The explicit marker makes the
    reviewer/adjudicator input limitation auditable rather than silently dropping
    context when the API request-size guard is reached.
    """
    encoded = text.encode("utf-8")
    digest = hashlib.sha256(encoded).hexdigest()
    if len(encoded) <= maximum_utf8_bytes:
        return text, {"truncated": False, "original_utf8_bytes": len(encoded), "sha256": digest}
    marker = (
        "\n\n[DIFF TRUNCATED BY FROZEN CONTEXT POLICY; full SHA-256=" + digest
        + f"; original UTF-8 bytes={len(encoded)}]\n"
    )
    budget = maximum_utf8_bytes - len(marker.encode("utf-8"))
    if budget <= 0:
        raise HarnessError("Frozen visible-diff cap is too small for its audit marker")
    prefix = encoded[:budget]
    while prefix:
        try:
            visible = prefix.decode("utf-8")
            break
        except UnicodeDecodeError:
            prefix = prefix[:-1]
    else:
        raise HarnessError("Cannot create UTF-8-safe bounded diff")
    return visible + marker, {"truncated": True, "original_utf8_bytes": len(encoded), "sha256": digest}


def _cleanup_successful_run_scratch(run_root: Path) -> None:
    """Remove reproducible transient copies after their bounded evidence is persisted."""
    if run_root.parent.name != "runs":
        raise HarnessError("Refusing to clean a run root outside the execution runs directory")
    for name in (
        "workspace",
        "hidden_evaluator_initial",
        "hidden_evaluator_final",
        "evaluator_output_initial",
        "evaluator_output_final",
    ):
        path = run_root / name
        if path.exists() or path.is_symlink():
            # Runtime overlays and compiled cache paths are deliberately read-only.
            # This scoped deletion preserves only durable audit artefacts alongside
            # the run root (tool JSONL, diffs, result.json).
            errors: list[dict[str, Any]] = []
            for attempt in range(1, 4):
                try:
                    subprocess.run(["sudo", "rm", "-rf", "--", str(path)], check=True,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                    errors = []
                    break
                except subprocess.CalledProcessError as exc:
                    errors.append({
                        "attempt": attempt,
                        "returncode": exc.returncode,
                        "stderr": (exc.stderr or "")[-500:],
                    })
                    if attempt < 3:
                        time.sleep(0.25 * attempt)
            if errors and (path.exists() or path.is_symlink()):
                # Scratch cleanup must not erase a termination record or abort
                # subsequent matrix rows. Keep the leftover scoped path explicit.
                atomic_write_json(run_root / "cleanup_failure.json", {
                    "path": name,
                    "attempts": errors,
                    "remaining": True,
                })


def _remove_staged_dependencies(path: Path, output_root: Path) -> None:
    """Remove only harness-created read-only dependency staging under this run root."""
    safe_parent = output_root / "shared_runtime_dependencies"
    if path.parent != safe_parent or safe_parent.parent != output_root:
        raise HarnessError("Refusing to remove dependencies outside this execution output root")
    # stage_dependencies intentionally makes every package cache read-only.  The
    # host cleanup needs elevated deletion but is strictly limited to this freshly
    # created output subtree; corpus sources and evaluator assets are not children.
    subprocess.run(["sudo", "rm", "-rf", "--", str(path)], check=True)


def _initialize_synthetic_git(workspace: Path) -> dict[str, Any]:
    """Create a reproducible local C0-only repository with no remote or prior history."""
    env = {
        "PATH": "/usr/bin:/bin",
        "HOME": "/nonexistent",
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_GLOBAL": "/dev/null",
        "GIT_AUTHOR_NAME": "Benchmark C0",
        "GIT_AUTHOR_EMAIL": "c0@example.invalid",
        "GIT_COMMITTER_NAME": "Benchmark C0",
        "GIT_COMMITTER_EMAIL": "c0@example.invalid",
        "GIT_AUTHOR_DATE": "2000-01-01T00:00:00Z",
        "GIT_COMMITTER_DATE": "2000-01-01T00:00:00Z",
    }

    def run_git(*args: str) -> str:
        completed = subprocess.run(
            ["git", *args], cwd=workspace, env=env, check=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
        )
        return completed.stdout.strip()

    run_git("init", "--quiet", "--initial-branch=main", "--template=/dev/null")
    run_git("config", "core.filemode", "false")
    run_git("config", "gc.auto", "0")
    run_git("config", "gc.autoDetach", "false")
    run_git("config", "maintenance.auto", "false")
    run_git("add", "--force", "--all")
    run_git("commit", "--quiet", "--allow-empty", "-m", "Synthetic baseline: C0")
    head = run_git("rev-parse", "HEAD")
    remotes = run_git("remote")
    history_count = run_git("rev-list", "--count", "HEAD")
    if remotes or history_count != "1":
        raise HarnessError("Synthetic Git baseline must contain exactly one commit and no remotes")
    return {"baseline_commit": head, "history_commits": 1, "remotes": [], "network_access": False}


def _run_label(issue_id: str, author_model: str, reviewer_model: str, replicate: int) -> str:
    return f"{issue_id}__a-{_safe_component(author_model)}__r-{_safe_component(reviewer_model)}__rep-{replicate}"


def _terminated_run_record(
    *, issue_id: str, author_model: str, reviewer_model: str, replicate: int, error: Exception, run_root: Path
) -> dict[str, Any]:
    """Record a non-retried expected agent/API termination as a full matrix observation."""
    record = {
        "issue_id": issue_id,
        "author_model": author_model,
        "reviewer_model": reviewer_model,
        "replicate": replicate,
        "status": "terminated_before_complete_workflow",
        "termination": {
            "type": type(error).__name__,
            "category": getattr(error, "category", "stage_or_transport_termination"),
            "message": str(error),
        },
        "initial": {"outcome": "not_evaluated_due_to_termination"},
        "final": {"outcome": "not_evaluated_due_to_termination"},
    }
    if run_root.exists():
        diagnostic = run_root / "structured_output_failure.json"
        if diagnostic.is_file():
            record["diagnostic_artifacts"] = ["structured_output_failure.json"]
        atomic_write_json(run_root / "result.json", record)
        _cleanup_successful_run_scratch(run_root)
    return record


def _parse_structured_response(*, role: str, text: str, turns: list[dict[str, Any]],
                               run_root: Path, parser: Any) -> Any:
    try:
        return parser(text)
    except StageError as exc:
        # Run roots are private (0700); retain only the stage output, not prompts,
        # credentials, hidden evaluator data, or the full transport response.
        atomic_write_json(run_root / "structured_output_failure.json", {
            "stage": role,
            "error_type": type(exc).__name__,
            "error": str(exc),
            "raw_response_text": text,
            "turns": turns,
            "finish_reason": turns[-1].get("finish_reason") if turns else None,
        })
        raise


def _run_one(
    *,
    issue: dict[str, Any],
    author_model: str,
    reviewer_model: str,
    replicate: int,
    root: Path,
    client: OpenRouterClient,
    config: dict[str, Any],
    dependencies: dict[str, Path],
) -> dict[str, Any]:
    """Run C0 -> author C1 -> reviewer -> adjudicator C2 with hidden evaluation only outside agents."""
    label = _run_label(issue["id"], author_model, reviewer_model, replicate)
    run_root = root / "runs" / label
    if run_root.exists():
        raise HarnessError(f"Run artifact already exists: {run_root}")
    run_root.mkdir(parents=True, mode=0o700)
    workspace = run_root / "workspace"
    allow_source_links = issue.get("source_allow_internal_relative_symlinks", False)
    copy_regular_tree(Path(issue["source_path"]), workspace, allow_internal_relative_symlinks=allow_source_links)
    source_links = internal_relative_symlink_map(workspace) if allow_source_links else None
    if tree_sha256(workspace, allow_internal_relative_symlinks=allow_source_links) != issue["source_tree_sha256"]:
        raise HarnessError(f"Staged C0 source digest mismatch for issue {issue['id']}")
    assert_workspace_hygiene(workspace, allowed_internal_relative_symlinks=source_links)
    runtime = runtime_spec(issue)
    prepare_runtime_workspace(workspace, runtime)
    synthetic_git = _initialize_synthetic_git(workspace)
    atomic_write_json(run_root / "agent_environment.json", {
        "git": synthetic_git,
        "toolchain_path": "/usr/local/bin:/usr/bin:/bin",
        "issue_id": issue["id"],
    })
    tool_limits = config.get("tool_limits", {})
    audit = {"issue_id": issue["id"], "author_model": author_model, "reviewer_model": reviewer_model, "replicate": replicate}
    before = snapshot_tree(workspace, allow_internal_relative_symlinks=allow_source_links)

    author_tools = ToolRunner(workspace, dependencies, run_root / "author_tools.jsonl", writable=True,
                              limits=tool_limits, max_commands=config["limits"]["author"]["max_commands"], runtime=runtime,
                              allowed_internal_relative_symlinks=source_links, allow_synthetic_git=True)
    author_system, author_user = author_prompts(issue["public_task"])
    author = run_agent_stage(client=client, model_id=author_model, role="author", system_prompt=author_system,
                             user_prompt=author_user, tool_runner=author_tools, limits=config["limits"]["author"], audit=audit)
    assert_workspace_hygiene(workspace, allowed_internal_relative_symlinks=source_links, allow_synthetic_git=True)
    initial_snapshot = snapshot_tree(workspace, allow_internal_relative_symlinks=allow_source_links)
    initial_diff = render_snapshot_patch(before, initial_snapshot, "C0", "C1")
    _write_text(run_root / "initial.diff", initial_diff)
    visible_initial_diff, visible_diff_metadata = _bounded_prompt_text(initial_diff, MAX_VISIBLE_DIFF_UTF8_BYTES)

    initial_eval_stage = stage_hidden_evaluator(issue, workspace, run_root / "hidden_evaluator_initial")
    initial_evaluation = run_hidden_evaluator(issue=issue, staged=initial_eval_stage, dependencies=dependencies,
                                              output_dir=run_root / "evaluator_output_initial",
                                              output_chars=int(tool_limits.get("output_chars", 8000)))
    # The initial outcome cannot be exposed to any agent: the reviewer is called
    # only with the public task and public initial diff.
    reviewer_tools = ToolRunner(workspace, dependencies, run_root / "reviewer_tools.jsonl", writable=False,
                                limits=tool_limits, max_commands=config["limits"]["review"]["max_commands"], runtime=runtime,
                                allowed_internal_relative_symlinks=source_links, allow_synthetic_git=True)
    reviewer_system, reviewer_user = reviewer_prompts(issue["public_task"], visible_initial_diff)
    reviewer = run_agent_stage(client=client, model_id=reviewer_model, role="review", system_prompt=reviewer_system,
                               user_prompt=reviewer_user, tool_runner=reviewer_tools, limits=config["limits"]["review"], audit=audit)
    review = _parse_structured_response(
        role="review", text=reviewer.final_text, turns=list(reviewer.turns),
        run_root=run_root, parser=parse_review_report,
    )
    assert_workspace_hygiene(workspace, allowed_internal_relative_symlinks=source_links, allow_synthetic_git=True)

    adjudicator_tools = ToolRunner(workspace, dependencies, run_root / "adjudicator_tools.jsonl", writable=True,
                                   limits=tool_limits, max_commands=config["limits"]["adjudicate"]["max_commands"], runtime=runtime,
                                   allowed_internal_relative_symlinks=source_links, allow_synthetic_git=True)
    adjudicator_system, adjudicator_user = adjudicator_prompts(issue["public_task"], visible_initial_diff, review)
    adjudicator = run_agent_stage(client=client, model_id=author_model, role="adjudicate", system_prompt=adjudicator_system,
                                  user_prompt=adjudicator_user, tool_runner=adjudicator_tools,
                                  limits=config["limits"]["adjudicate"], audit=audit)
    adjudication = _parse_structured_response(
        role="adjudicate", text=adjudicator.final_text, turns=list(adjudicator.turns),
        run_root=run_root, parser=lambda text: parse_adjudication(text, review),
    )
    assert_workspace_hygiene(workspace, allowed_internal_relative_symlinks=source_links, allow_synthetic_git=True)
    final_snapshot = snapshot_tree(workspace, allow_internal_relative_symlinks=allow_source_links)
    final_diff = render_snapshot_patch(before, final_snapshot, "C0", "C2")
    review_delta = render_snapshot_patch(initial_snapshot, final_snapshot, "C1", "C2")
    _write_text(run_root / "final.diff", final_diff)
    _write_text(run_root / "review_delta.diff", review_delta)

    final_eval_stage = stage_hidden_evaluator(issue, workspace, run_root / "hidden_evaluator_final")
    final_evaluation = run_hidden_evaluator(issue=issue, staged=final_eval_stage, dependencies=dependencies,
                                            output_dir=run_root / "evaluator_output_final",
                                            output_chars=int(tool_limits.get("output_chars", 8000)))
    result = {
        "issue_id": issue["id"],
        "author_model": author_model,
        "reviewer_model": reviewer_model,
        "replicate": replicate,
        "agent_environment": {
            "synthetic_git_baseline_commit": synthetic_git["baseline_commit"],
            "history_commits": synthetic_git["history_commits"],
            "remotes": [],
        },
        "initial": {"outcome": initial_evaluation["outcome"], "evaluation": initial_evaluation, "diff": "initial.diff"},
        "final": {"outcome": final_evaluation["outcome"], "evaluation": final_evaluation, "diff": "final.diff", "review_delta": "review_delta.diff"},
        "visible_initial_diff": visible_diff_metadata,
        "review": review_report_json(review),
        "adjudication": adjudication_json(adjudication),
        "stages": {"author": {"turns": list(author.turns), "final_text": author.final_text},
                   "reviewer": {"turns": list(reviewer.turns), "final_text": reviewer.final_text},
                   "adjudicator": {"turns": list(adjudicator.turns), "final_text": adjudicator.final_text}},
    }
    atomic_write_json(run_root / "result.json", result)
    _cleanup_successful_run_scratch(run_root)
    return result


def execute(config: dict[str, Any], manifest: dict[str, Any], authorization: dict[str, Any], output_root: Path) -> None:
    if output_root.exists():
        raise HarnessError("--output-dir must not already exist, to prevent mixing runs")
    output_root.mkdir(parents=True, mode=0o700)
    try:
        atomic_write_json(output_root / "config.json", config)
        atomic_write_json(output_root / "manifest.json", manifest)
        configured_model_ids = [item["id"] for item in config["models"]]
        write_request_contract(output_root / "openrouter_request_contract.json", configured_model_ids)
        carryover = float(config.get("prior_cumulative_spend_usd", config.get("prior_aborted_attempt_spend_usd", 0.0)))
        prior_reservations = config.get("prior_unresolved_reservations", [])
        ledger_reservations = {
            item["request_id"]: {
                "estimated_usd": float(item["estimated_usd"]),
                "details": item["details"],
                "reserved_at": float(item["reserved_at"]),
            }
            for item in prior_reservations
        }
        atomic_write_json(output_root / "budget_carryover.json", {
            "known_preflight_spend_usd": config["known_preflight_spend_usd"],
            "prior_cumulative_spend_usd": carryover,
            "ledger_initial_spend_usd": config["known_preflight_spend_usd"] + carryover,
            "prior_unresolved_reservations": prior_reservations,
            "ledger_initial_reserved_usd": sum(item["estimated_usd"] for item in prior_reservations),
            "max_total_usd": config["max_total_usd"],
        })
        ledger = CostLedger(output_root / "accounting", config["max_total_usd"],
                            initial_spend_usd=config["known_preflight_spend_usd"] + carryover,
                            initial_reservations=ledger_reservations)
        model_prices = {item["id"]: item for item in config["models"]}
        client = OpenRouterClient(ledger=ledger, event_path=output_root / "openrouter_events.jsonl", model_prices=model_prices,
                                  api_key_env=config["openrouter"]["api_key_env"],
                                  timeout_seconds=config["openrouter"]["timeout_seconds"])
        results: list[dict[str, Any]] = []
        for issue in manifest["issues"]:
            source_dependencies = {item["name"]: Path(item["source_path"]) for item in issue.get("dependencies", [])}
            dependency_hashes = {item["name"]: item["tree_sha256"] for item in issue.get("dependencies", [])}
            dependency_link_policy = {
                item["name"]: item.get("allow_internal_relative_symlinks", False)
                for item in issue.get("dependencies", [])
            }
            dependency_root = output_root / "shared_runtime_dependencies" / issue["id"]
            dependencies = stage_dependencies(
                source_dependencies,
                dependency_root,
                expected_tree_sha256=dependency_hashes,
                allow_internal_relative_symlinks=dependency_link_policy,
            )
            try:
                for author_model, reviewer_model in directed_pairs(configured_model_ids):
                    for replicate in range(1, config["replicates"] + 1):
                        label = _run_label(issue["id"], author_model, reviewer_model, replicate)
                        run_root = output_root / "runs" / label
                        try:
                            record = _run_one(issue=issue, author_model=author_model, reviewer_model=reviewer_model,
                                              replicate=replicate, root=output_root, client=client, config=config,
                                              dependencies=dependencies)
                        except (StageError, OpenRouterError) as exc:
                            # Per protocol, exhausted tools/turns and transport/model
                            # terminations are retained as outcomes, never silently retried.
                            record = _terminated_run_record(
                                issue_id=issue["id"], author_model=author_model, reviewer_model=reviewer_model,
                                replicate=replicate, error=exc, run_root=run_root,
                            )
                        results.append(record)
                        atomic_write_json(output_root / "results.json", results)
            finally:
                # Every completed run retains bounded diffs/logs/evaluator records;
                # this is only the regenerated immutable runtime copy.
                if dependency_root.exists() or dependency_root.is_symlink():
                    _remove_staged_dependencies(dependency_root, output_root)
        atomic_write_json(output_root / "execution_complete.json", {
            "completed_at": time.time(), "records": len(results),
            "expected_directed_pairs": len(directed_pairs(configured_model_ids)),
            "replicates": config["replicates"], "status": "completed",
        })
    except Exception:
        # Retain every partial artifact and reservation for transparent recovery.
        atomic_write_json(output_root / "execution_incomplete.json", {"stopped_at": time.time(), "status": "failed_or_interrupted"})
        raise


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="PR-review harness: validation is safe; execution requires --execute.")
    parser.add_argument("--config", type=Path, required=True, help="Зафиксированный JSON config без API-ключа")
    parser.add_argument("--manifest", type=Path, required=True, help="Frozen manifest с корректным freeze_sha256")
    parser.add_argument("--authorization", type=Path, default=HERE.parent / "preflight" / "budget_authorization.json",
                        help="Утверждённый budget_authorization.json")
    parser.add_argument("--model-selection", type=Path, default=HERE.parent / "preflight" / "model_selection.json",
                        help="Предэкспериментальный model_selection.json")
    parser.add_argument("--output-dir", type=Path, help="Новый каталог артефактов; требуется только с --execute")
    parser.add_argument("--execute", action="store_true", help="Явно разрешить реальные API-вызовы и sandbox-команды")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        config, manifest, authorization = validate_inputs(args.config, args.manifest, args.authorization, args.model_selection)
        if not args.execute:
            if args.output_dir is not None:
                raise HarnessError("--output-dir допускается только вместе с --execute")
            print("Валидация пройдена. Реальный запуск заблокирован: добавьте явный --execute после проверки freeze.")
            return 0
        if args.output_dir is None:
            raise HarnessError("Для --execute необходим новый --output-dir")
        execute(config, manifest, authorization, args.output_dir)
        print("Экспериментальный запуск завершён; результаты сохранены в " + str(args.output_dir))
        return 0
    except HarnessError as exc:
        print("ОШИБКА HARNESS: " + str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
