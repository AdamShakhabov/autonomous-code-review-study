#!/usr/bin/env python3
"""Агрегация результатов PR-review harness без внешних зависимостей."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import random
import statistics
import sys
from typing import Any, Iterable

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from pr_harness.core import HarnessError, MODEL_IDS, atomic_write_json, directed_pairs, require_name  # noqa: E402

ALLOWED_OUTCOMES = {"pass", "fail", "timeout", "error", "not_evaluated_due_to_termination"}


def _outcome(record: dict[str, Any], stage: str) -> str:
    value = record.get(stage)
    if not isinstance(value, dict) or value.get("outcome") not in ALLOWED_OUTCOMES:
        raise HarnessError(f"Record {record.get('issue_id', '<unknown>')} has invalid {stage}.outcome")
    return value["outcome"]


def _success(record: dict[str, Any], stage: str) -> float:
    return 1.0 if _outcome(record, stage) == "pass" else 0.0


def validate_records(records: list[dict[str, Any]], model_ids: Iterable[str] = MODEL_IDS) -> None:
    """Require a complete rectangular issue × directed-pair × replicate result set."""
    if not isinstance(records, list) or not records:
        raise HarnessError("Results must be a non-empty JSON array")
    selected_models = list(model_ids)
    if len(selected_models) not in {2, 3} or len(set(selected_models)) != len(selected_models) or not set(selected_models).issubset(set(MODEL_IDS)):
        raise HarnessError("Analysis requires two or three unique models from the pinned selection")
    expected_pairs = set(directed_pairs(selected_models))
    seen: set[tuple[str, str, str, int]] = set()
    by_issue: dict[str, list[dict[str, Any]]] = {}
    all_replicates: set[int] = set()
    for record in records:
        if not isinstance(record, dict):
            raise HarnessError("Every result must be an object")
        issue_id = require_name(record.get("issue_id"), "result.issue_id")
        author, reviewer = record.get("author_model"), record.get("reviewer_model")
        if author not in selected_models or reviewer not in selected_models or author == reviewer:
            raise HarnessError("Result uses a model outside the selected directed author→reviewer pairs")
        replicate = record.get("replicate")
        if not isinstance(replicate, int) or replicate <= 0:
            raise HarnessError("result.replicate must be a positive integer")
        _outcome(record, "initial")
        _outcome(record, "final")
        key = (issue_id, author, reviewer, replicate)
        if key in seen:
            raise HarnessError("Duplicate issue/pair/replicate result")
        seen.add(key)
        by_issue.setdefault(issue_id, []).append(record)
        all_replicates.add(replicate)
    actual_pairs = {(record["author_model"], record["reviewer_model"]) for record in records}
    if actual_pairs != expected_pairs:
        missing = sorted(expected_pairs - actual_pairs)
        unexpected = sorted(actual_pairs - expected_pairs)
        raise HarnessError(f"Expected exactly {len(expected_pairs)} directed pairs; missing={missing}, unexpected={unexpected}")
    expected_replicates = set(range(1, max(all_replicates) + 1))
    if all_replicates != expected_replicates:
        raise HarnessError("Replicates must be contiguous starting at 1")
    for issue_id, rows in by_issue.items():
        issue_pairs = {(row["author_model"], row["reviewer_model"]) for row in rows}
        if issue_pairs != expected_pairs:
            raise HarnessError(f"Issue {issue_id} does not contain all selected directed pairs")
        for pair in expected_pairs:
            reps = {row["replicate"] for row in rows if (row["author_model"], row["reviewer_model"]) == pair}
            if reps != expected_replicates:
                raise HarnessError(f"Issue {issue_id}, pair {pair} has incomplete replicate coverage")


def _rate(rows: Iterable[dict[str, Any]], stage: str) -> float:
    listed = list(rows)
    return sum(_success(row, stage) for row in listed) / len(listed)


def _metrics(rows: list[dict[str, Any]]) -> dict[str, float | int]:
    initial = _rate(rows, "initial")
    final = _rate(rows, "final")
    terminated = sum(row.get("status") == "terminated_before_complete_workflow" for row in rows)
    return {
        "n": len(rows),
        "terminated_before_complete_workflow": terminated,
        "initial_pass_rate": initial,
        "final_pass_rate": final,
        "review_uplift": final - initial,
    }


def _quantile(values: list[float], probability: float) -> float:
    if not values:
        raise HarnessError("Cannot compute a quantile of no values")
    ordered = sorted(values)
    index = (len(ordered) - 1) * probability
    lower, upper = int(index), min(int(index) + 1, len(ordered) - 1)
    fraction = index - lower
    return ordered[lower] * (1 - fraction) + ordered[upper] * fraction


def issue_cluster_bootstrap(issue_rows: dict[str, list[dict[str, Any]]], *, samples: int = 2000, seed: int = 20261022) -> dict[str, Any]:
    """Resample issue clusters—not individual runs—to preserve within-issue dependence."""
    if not isinstance(samples, int) or not 100 <= samples <= 100_000:
        raise HarnessError("bootstrap samples must be an integer from 100 to 100000")
    issue_ids = sorted(issue_rows)
    if not issue_ids:
        raise HarnessError("No issue clusters for bootstrap")
    per_issue = {issue_id: _metrics(rows) for issue_id, rows in issue_rows.items()}
    rng = random.Random(seed)
    simulated: dict[str, list[float]] = {"initial_pass_rate": [], "final_pass_rate": [], "review_uplift": []}
    for _ in range(samples):
        draw = [rng.choice(issue_ids) for _ in issue_ids]
        for metric in simulated:
            simulated[metric].append(statistics.fmean(float(per_issue[item][metric]) for item in draw))
    return {
        "cluster": "issue",
        "samples": samples,
        "seed": seed,
        "confidence_level": 0.95,
        "intervals": {
            metric: {"low": _quantile(values, 0.025), "high": _quantile(values, 0.975)}
            for metric, values in simulated.items()
        },
    }


def aggregate(records: list[dict[str, Any]], *, model_ids: Iterable[str] = MODEL_IDS,
              bootstrap_samples: int = 2000, seed: int = 20261022) -> dict[str, Any]:
    """Produce issue-level, pair-level, and cluster-bootstrap summaries."""
    selected_models = list(model_ids)
    validate_records(records, selected_models)
    by_issue: dict[str, list[dict[str, Any]]] = {}
    by_pair: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for row in records:
        by_issue.setdefault(row["issue_id"], []).append(row)
        by_pair.setdefault((row["author_model"], row["reviewer_model"]), []).append(row)
    issue_metrics = {issue_id: _metrics(rows) for issue_id, rows in sorted(by_issue.items())}
    # The estimand is the mean issue effect.  With an intentionally balanced
    # design it equals pooled data, but expressing it this way prevents an issue
    # with accidental extra rows from receiving extra analytical weight.
    overall = {
        key: statistics.fmean(float(metric[key]) for metric in issue_metrics.values())
        for key in ("initial_pass_rate", "final_pass_rate", "review_uplift")
    }
    overall["issues"] = len(issue_metrics)
    overall["runs"] = len(records)
    pairs = []
    for author, reviewer in directed_pairs(selected_models):
        item = _metrics(by_pair[(author, reviewer)])
        pairs.append({"author_model": author, "reviewer_model": reviewer, **item})
    return {
        "analysis_version": 1,
        "outcome_definition": "pass iff the manifest-provided evaluator exited successfully; fail/timeout/error and a non-retried workflow termination count as not-pass",
        "overall_issue_weighted": overall,
        "issues": [{"issue_id": issue_id, **metrics} for issue_id, metrics in issue_metrics.items()],
        "directed_pairs": pairs,
        "issue_cluster_bootstrap": issue_cluster_bootstrap(by_issue, samples=bootstrap_samples, seed=seed),
    }


def load_records(path: Path) -> list[dict[str, Any]]:
    text = path.read_text(encoding="utf-8")
    if path.suffix == ".jsonl":
        values = [json.loads(line) for line in text.splitlines() if line.strip()]
    else:
        values = json.loads(text)
    if not isinstance(values, list):
        raise HarnessError("Input must be a JSON array or JSONL stream")
    return values


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Анализ issue-level результатов PR-review harness.")
    parser.add_argument("--results", type=Path, required=True, help="results.json или JSONL с полными записями")
    parser.add_argument("--output", type=Path, required=True, help="Новый JSON-файл аналитического результата")
    parser.add_argument("--bootstrap-samples", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=20261022)
    parser.add_argument("--models", nargs="+", choices=MODEL_IDS, default=list(MODEL_IDS),
                        help="Точный список моделей frozen matrix; для V5 укажите OpenAI и Anthropic")
    args = parser.parse_args(argv)
    try:
        if args.output.exists():
            raise HarnessError("--output already exists")
        result = aggregate(load_records(args.results), model_ids=args.models,
                           bootstrap_samples=args.bootstrap_samples, seed=args.seed)
        atomic_write_json(args.output, result)
        print("Анализ сохранён: " + str(args.output))
        return 0
    except (HarnessError, OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        print("ОШИБКА АНАЛИЗА: " + str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
