# Harness source

This directory contains the study-authored harness components relevant to the V8 workflow and the original aggregate analysis script. It intentionally excludes task-specific validator scripts, hidden evaluator assets, dependency caches, and raw execution logs.

`analyze_results.py` consumes private full records. For the content-reduced public CSV tables, use `../scripts/reproduce_paper_tables.py`.

No credentials are included. Running `run_experiment.py` requires external model credentials plus private task/evaluator assets that this public release intentionally omits.
