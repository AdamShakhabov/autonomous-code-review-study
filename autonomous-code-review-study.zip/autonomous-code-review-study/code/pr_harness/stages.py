"""Agent-stage protocol without evaluator visibility.

This module only orchestrates a supplied OpenRouterClient.  It never discovers
or runs tests, and all local effects flow through ToolRunner's constrained API.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from typing import Any

from .core import HarnessError, canonical_json_bytes
from .isolation import ToolRunner
from .openrouter import Completion, OpenRouterClient


class StageError(HarnessError):
    """A malformed tool call, exhausted turn budget, or invalid structured result."""


class ProtocolViolationError(StageError):
    """The model attempted an action explicitly forbidden by the frozen stage protocol."""

    category = "invalid_final_tool_call"


class ToolCallBudgetError(StageError):
    """The model exceeded the per-stage count of individual tool calls."""

    category = "tool_call_budget_exhausted"


MAX_TOOL_RESULT_HISTORY_UTF8_BYTES = 2_000
MAX_REVIEW_FINDINGS = 10
MAX_REVIEW_SUMMARY_CHARS = 160
MAX_FINDING_CLAIM_CHARS = 100
MAX_FINDING_RECOMMENDATION_CHARS = 100
MAX_ADJUDICATION_SUMMARY_CHARS = 160
MAX_ADJUDICATION_RATIONALE_CHARS = 120


def _nullable(kind: str) -> dict[str, Any]:
    return {"anyOf": [{"type": kind}, {"type": "null"}]}


def review_response_format() -> dict[str, Any]:
    """Portable JSON Schema; maxItems is enforced locally for provider compatibility."""
    finding = {
        "type": "object",
        "properties": {
            "id": {"type": "string"},
            "severity": {"type": "string", "enum": ["blocker", "major", "minor", "nit"]},
            "path": _nullable("string"),
            "line": _nullable("integer"),
            "claim": {"type": "string"},
            "recommendation": {"type": "string"},
        },
        "required": ["id", "severity", "path", "line", "claim", "recommendation"],
        "additionalProperties": False,
    }
    return {
        "type": "json_schema",
        "json_schema": {
            "name": "review_report",
            "strict": True,
            "schema": {
                "type": "object",
                "properties": {
                    "verdict": {"type": "string", "enum": ["approve", "request_changes", "comment"]},
                    "summary": {"type": "string"},
                    "findings": {"type": "array", "items": finding},
                },
                "required": ["verdict", "summary", "findings"],
                "additionalProperties": False,
            },
        },
    }


def adjudication_response_format() -> dict[str, Any]:
    decision = {
        "type": "object",
        "properties": {
            "finding_id": {"type": "string"},
            "decision": {"type": "string", "enum": ["accepted", "rejected", "not_actionable"]},
            "rationale": {"type": "string"},
        },
        "required": ["finding_id", "decision", "rationale"],
        "additionalProperties": False,
    }
    return {
        "type": "json_schema",
        "json_schema": {
            "name": "adjudication",
            "strict": True,
            "schema": {
                "type": "object",
                "properties": {
                    "summary": {"type": "string"},
                    "decisions": {"type": "array", "items": decision},
                },
                "required": ["summary", "decisions"],
                "additionalProperties": False,
            },
        },
    }


def _bounded_tool_history(text: str) -> str:
    """Bound only the model-visible history; ToolRunner keeps the full audit log."""
    raw = text.encode("utf-8")
    if len(raw) <= MAX_TOOL_RESULT_HISTORY_UTF8_BYTES:
        return text
    marker = "\n[TOOL RESULT TRUNCATED IN MODEL HISTORY; inspect a narrower path/query if needed]\n"
    prefix = raw[: MAX_TOOL_RESULT_HISTORY_UTF8_BYTES - len(marker.encode("utf-8"))]
    while prefix:
        try:
            return prefix.decode("utf-8") + marker
        except UnicodeDecodeError:
            prefix = prefix[:-1]
    raise StageError("Tool-history cap cannot preserve UTF-8")


@dataclass(frozen=True)
class ReviewFinding:
    finding_id: str
    severity: str
    path: str | None
    line: int | None
    claim: str
    recommendation: str


@dataclass(frozen=True)
class ReviewReport:
    verdict: str
    summary: str
    findings: tuple[ReviewFinding, ...]


@dataclass(frozen=True)
class AdjudicationDecision:
    finding_id: str
    decision: str
    rationale: str


@dataclass(frozen=True)
class Adjudication:
    summary: str
    decisions: tuple[AdjudicationDecision, ...]


@dataclass(frozen=True)
class StageResult:
    final_text: str
    turns: tuple[dict[str, Any], ...]


def _json_object_from_text(text: str) -> dict[str, Any]:
    if not isinstance(text, str):
        raise StageError("Structured response must be a string")
    candidate = text.strip()
    if candidate.startswith("```") and candidate.endswith("```"):
        candidate = candidate.split("\n", 1)[1] if "\n" in candidate else ""
        candidate = candidate.rsplit("```", 1)[0].strip()
    try:
        value = json.loads(candidate)
    except json.JSONDecodeError as exc:
        raise StageError("Structured response is not a JSON object") from exc
    if not isinstance(value, dict):
        raise StageError("Structured response root must be an object")
    return value


def parse_review_report(text: str) -> ReviewReport:
    value = _json_object_from_text(text)
    if set(value) != {"verdict", "summary", "findings"}:
        raise StageError("Review JSON must contain exactly verdict, summary, findings")
    verdict, summary, findings = value["verdict"], value["summary"], value["findings"]
    if verdict not in {"approve", "request_changes", "comment"}:
        raise StageError("Review verdict is invalid")
    if not isinstance(summary, str) or not summary.strip() or len(summary) > MAX_REVIEW_SUMMARY_CHARS:
        raise StageError("Review summary is invalid")
    if not isinstance(findings, list) or len(findings) > MAX_REVIEW_FINDINGS:
        raise StageError("Review findings must be an array of at most 10 entries")
    parsed: list[ReviewFinding] = []
    ids: set[str] = set()
    for item in findings:
        if not isinstance(item, dict) or set(item) != {"id", "severity", "path", "line", "claim", "recommendation"}:
            raise StageError("Every review finding has a fixed six-field schema")
        finding_id = item["id"]
        if not isinstance(finding_id, str) or not finding_id or len(finding_id) > 80 or finding_id in ids:
            raise StageError("Review finding id is invalid or duplicated")
        ids.add(finding_id)
        if item["severity"] not in {"blocker", "major", "minor", "nit"}:
            raise StageError("Review finding severity is invalid")
        path, line = item["path"], item["line"]
        if path is not None and (not isinstance(path, str) or not path or path.startswith("/") or ".." in path.split("/")):
            raise StageError("Review finding path is unsafe")
        if line is not None and (not isinstance(line, int) or line <= 0):
            raise StageError("Review finding line is invalid")
        if (not isinstance(item["claim"], str) or not item["claim"].strip()
                or len(item["claim"]) > MAX_FINDING_CLAIM_CHARS):
            raise StageError("Review finding claim must be non-empty and at most 100 characters")
        if (not isinstance(item["recommendation"], str) or not item["recommendation"].strip()
                or len(item["recommendation"]) > MAX_FINDING_RECOMMENDATION_CHARS):
            raise StageError("Review finding recommendation must be non-empty and at most 100 characters")
        parsed.append(ReviewFinding(finding_id, item["severity"], path, line, item["claim"], item["recommendation"]))
    return ReviewReport(verdict, summary, tuple(parsed))


def parse_adjudication(text: str, review: ReviewReport) -> Adjudication:
    value = _json_object_from_text(text)
    if set(value) != {"summary", "decisions"}:
        raise StageError("Adjudication JSON must contain exactly summary and decisions")
    summary, decisions = value["summary"], value["decisions"]
    if not isinstance(summary, str) or not summary.strip() or len(summary) > MAX_ADJUDICATION_SUMMARY_CHARS:
        raise StageError("Adjudication summary is invalid")
    if not isinstance(decisions, list) or len(decisions) != len(review.findings):
        raise StageError("Adjudication must decide every reviewer finding exactly once")
    expected = {item.finding_id for item in review.findings}
    parsed: list[AdjudicationDecision] = []
    seen: set[str] = set()
    for item in decisions:
        if not isinstance(item, dict) or set(item) != {"finding_id", "decision", "rationale"}:
            raise StageError("Every adjudication decision has a fixed three-field schema")
        finding_id = item["finding_id"]
        if not isinstance(finding_id, str) or finding_id not in expected or finding_id in seen:
            raise StageError("Adjudication finding_id is absent, unknown, or duplicated")
        seen.add(finding_id)
        if item["decision"] not in {"accepted", "rejected", "not_actionable"}:
            raise StageError("Adjudication decision is invalid")
        if (not isinstance(item["rationale"], str) or not item["rationale"].strip()
                or len(item["rationale"]) > MAX_ADJUDICATION_RATIONALE_CHARS):
            raise StageError("Adjudication rationale must be non-empty and at most 120 characters")
        parsed.append(AdjudicationDecision(finding_id, item["decision"], item["rationale"]))
    return Adjudication(summary, tuple(parsed))


def review_report_json(report: ReviewReport) -> dict[str, Any]:
    return {
        "verdict": report.verdict,
        "summary": report.summary,
        "findings": [
            {
                "id": item.finding_id,
                "severity": item.severity,
                "path": item.path,
                "line": item.line,
                "claim": item.claim,
                "recommendation": item.recommendation,
            }
            for item in report.findings
        ],
    }


def adjudication_json(value: Adjudication) -> dict[str, Any]:
    return {"summary": value.summary, "decisions": [asdict(item) for item in value.decisions]}


def _completion_message_for_history(message: dict[str, Any]) -> dict[str, Any]:
    """Keep only OpenAI-compatible assistant fields returned by the provider."""
    out: dict[str, Any] = {"role": "assistant", "content": message.get("content") or ""}
    if "tool_calls" in message:
        calls = message["tool_calls"]
        if not isinstance(calls, list):
            raise StageError("Provider tool_calls must be an array")
        out["tool_calls"] = calls
    return out


def _finish_reason(raw_response: dict[str, Any]) -> str | None:
    choices = raw_response.get("choices") if isinstance(raw_response, dict) else None
    if isinstance(choices, list) and choices and isinstance(choices[0], dict):
        value = choices[0].get("finish_reason")
        return value if isinstance(value, str) else None
    return None


def _compact_messages_for_request(
    *, messages: list[dict[str, Any]], client: OpenRouterClient, model_id: str,
    tools: list[dict[str, Any]], max_output_tokens: int, max_request_bytes: int,
    response_format: dict[str, Any] | None,
) -> tuple[list[dict[str, Any]], dict[str, int]]:
    """Keep task instructions and the latest useful tool context under the wire cap.

    Full tool output remains in ToolRunner's durable audit log. Only the model-visible
    copy is compacted; the agent can re-read files or rerun tests when older evidence
    has been evicted.
    """
    compacted = json.loads(json.dumps(messages, ensure_ascii=False))

    def size() -> int:
        measure = getattr(client, "serialized_request_size_bytes", None)
        if callable(measure):
            return measure(
                model_id=model_id, messages=compacted, tools=tools,
                max_output_tokens=max_output_tokens, response_format=response_format,
            )
        payload = {
            "model": model_id, "messages": compacted, "tools": tools,
            "tool_choice": "auto" if tools else "none", "plugins": [],
            "provider": {"order": [model_id.split("/", 1)[0]], "require_parameters": True,
                         "allow_fallbacks": False},
            "max_tokens": max_output_tokens,
        }
        if response_format is not None:
            payload["response_format"] = response_format
        return len(canonical_json_bytes(payload))

    before = size()
    dropped_cycles = 0
    shortened_results = 0
    shortened_calls = 0
    marker = "[Earlier tool exchanges omitted to fit the request bound. Full tool audit is retained; re-read files/tests before relying on older output.]"

    def remove_oldest_cycle() -> bool:
        nonlocal dropped_cycles
        start = next((i for i in range(2, len(compacted))
                      if compacted[i].get("role") == "assistant" and compacted[i].get("tool_calls")), None)
        if start is None:
            return False
        calls = compacted[start].get("tool_calls", [])
        call_ids = {item.get("id") for item in calls if isinstance(item, dict)}
        end = start + 1
        while end < len(compacted) and compacted[end].get("role") == "tool" and compacted[end].get("tool_call_id") in call_ids:
            end += 1
        if end == start + 1:
            end = start + 1
        del compacted[start:end]
        dropped_cycles += 1
        return True

    if before > max_request_bytes:
        # Add the note once, without editing the original task prompt.
        note_index = next((i for i, item in enumerate(compacted[2:], start=2)
                           if item.get("role") == "user" and item.get("content") == marker), None)
        if note_index is None:
            compacted.insert(2, {"role": "user", "content": marker})
        while size() > max_request_bytes and remove_oldest_cycle():
            pass

        # If one oversized cycle remains, shorten old model-visible tool returns
        # first, then historical tool-call arguments; the actual audit log is intact.
        for item in compacted:
            if size() <= max_request_bytes:
                break
            if item.get("role") == "tool" and isinstance(item.get("content"), str) and len(item["content"].encode("utf-8")) > 256:
                raw = item["content"].encode("utf-8")
                item["content"] = raw[:256].decode("utf-8", errors="ignore") + "\n[Older tool output shortened; consult workspace/audit log.]"
                shortened_results += 1
        for item in compacted:
            if size() <= max_request_bytes:
                break
            if item.get("role") == "assistant" and isinstance(item.get("tool_calls"), list):
                for call in item["tool_calls"]:
                    if size() <= max_request_bytes:
                        break
                    function = call.get("function") if isinstance(call, dict) else None
                    if isinstance(function, dict) and isinstance(function.get("arguments"), str) and len(function["arguments"].encode("utf-8")) > 256:
                        function["arguments"] = json.dumps({"omitted_for_context": "full call remains in local tool audit"})
                        shortened_calls += 1

    after = size()
    if after > max_request_bytes:
        raise StageError(
            f"Base task prompt plus current tools require {after} serialized bytes, above max_request_bytes={max_request_bytes}; no API request was sent"
        )
    return compacted, {
        "request_bytes_before_compaction": before,
        "request_bytes_sent": after,
        "dropped_tool_cycles": dropped_cycles,
        "shortened_tool_results": shortened_results,
        "shortened_tool_calls": shortened_calls,
    }


def run_agent_stage(
    *,
    client: OpenRouterClient,
    model_id: str,
    role: str,
    system_prompt: str,
    user_prompt: str,
    tool_runner: ToolRunner,
    limits: dict[str, Any],
    audit: dict[str, Any],
) -> StageResult:
    """Perform bounded chat/tool turns; evaluator assets are never an argument here."""
    if role not in {"author", "review", "adjudicate"}:
        raise StageError("Unknown stage role")
    if role == "review" and tool_runner.writable:
        raise StageError("Reviewer must receive a read-only ToolRunner")
    max_turns = limits.get("max_turns")
    if not isinstance(max_turns, int) or max_turns <= 0:
        raise StageError("Stage max_turns must be positive")
    max_tool_turns = limits.get("max_tool_turns", max_turns)
    max_tool_calls = limits.get("max_tool_calls", limits.get("max_commands", 0))
    if not isinstance(max_tool_turns, int) or not 0 <= max_tool_turns <= max_turns:
        raise StageError("Stage max_tool_turns must be between zero and max_turns")
    if not isinstance(max_tool_calls, int) or max_tool_calls < 0:
        raise StageError("Stage max_tool_calls must be non-negative")
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]
    turns: list[dict[str, Any]] = []
    schemas = tool_runner.schemas(tool_runner.writable)
    tool_calls_used = 0
    for turn_number in range(1, max_turns + 1):
        turn_tools = schemas if turn_number <= max_tool_turns else []
        response_format = (review_response_format() if role == "review" else
                           adjudication_response_format() if role == "adjudicate" else None)
        max_request_bytes = limits.get("max_request_bytes")
        request_messages = messages
        compaction = None
        if max_request_bytes is not None:
            if not isinstance(max_request_bytes, int) or isinstance(max_request_bytes, bool) or max_request_bytes <= 0:
                raise StageError("max_request_bytes must be a positive integer")
            request_messages, compaction = _compact_messages_for_request(
                messages=messages, client=client, model_id=model_id, tools=turn_tools,
                max_output_tokens=limits["max_tokens"], max_request_bytes=max_request_bytes,
                response_format=response_format,
            )
        completion: Completion = client.complete(
            model_id=model_id,
            messages=request_messages,
            tools=turn_tools,
            max_input_tokens=limits["max_input_tokens"],
            max_output_tokens=limits["max_tokens"],
            max_request_bytes=max_request_bytes,
            response_format=response_format,
            audit={**audit, "role": role, "turn": turn_number},
        )
        turns.append({
            "turn": turn_number,
            "request_id": completion.request_id,
            "model": completion.model,
            "provider": completion.provider,
            "usage": completion.usage,
            "cost_usd": completion.cost_usd,
            "generation_id": completion.generation_id,
            "finish_reason": _finish_reason(completion.raw_response),
            "context_compaction": compaction,
        })
        assistant_message = _completion_message_for_history(completion.message)
        messages.append(assistant_message)
        calls = assistant_message.get("tool_calls", [])
        if not calls:
            return StageResult(str(assistant_message["content"]), tuple(turns))
        if turn_number > max_tool_turns:
            raise ProtocolViolationError(
                f"{role} finalization turn attempted a tool call; tool execution was prohibited"
            )
        if tool_calls_used + len(calls) > max_tool_calls:
            raise ToolCallBudgetError(f"{role} stage exceeded its max_tool_calls without executing the over-budget batch")
        tool_calls_used += len(calls)
        for call in calls:
            if not isinstance(call, dict) or call.get("type") != "function" or not isinstance(call.get("id"), str):
                raise StageError("Provider emitted malformed function tool call")
            function = call.get("function")
            if not isinstance(function, dict) or not isinstance(function.get("name"), str) or not isinstance(function.get("arguments"), str):
                raise StageError("Provider emitted malformed function descriptor")
            try:
                arguments = json.loads(function["arguments"])
            except json.JSONDecodeError:
                tool_result = json.dumps({"ok": False, "error": "Tool arguments are not JSON"})
            else:
                if not isinstance(arguments, dict):
                    tool_result = json.dumps({"ok": False, "error": "Tool arguments must be an object"})
                else:
                    tool_result = tool_runner.run(function["name"], arguments)
            messages.append({"role": "tool", "tool_call_id": call["id"], "content": _bounded_tool_history(tool_result)})
    raise StageError(f"{role} stage exhausted its max_turns without a final response")


def author_prompts(public_task: str) -> tuple[str, str]:
    return (
        "You are the patch author. Work only in /workspace through the provided tools. "
        "Hidden tests and the evaluator are not available to you; do not attempt to find them. "
        "Make the smallest correct fix and run only the available local checks when useful. "
        "Use the terminal to inspect files, make focused edits, and run relevant local tests/build checks. "
        "Work iteratively: inspect, edit, test, and inspect failures; do not stop merely because the first search misses. "
        "You have up to twelve tool-enabled turns, followed by one final turn without tools. "
        "The final turn is reserved for a concise plain-text summary of changes and checks. "
        "In the final response, briefly describe the changes in plain text.",
        "Public issue description:\n\n" + public_task,
    )


def reviewer_prompts(public_task: str, initial_diff: str) -> tuple[str, str]:
    return (
        "You are the reviewer. The workspace is read-only; do not modify it and do not call tools. "
        "Hidden evaluator/tests are unavailable. Review the public task and the initial diff. "
        "Return ONLY JSON, without Markdown, using this exact schema. Include at most 10 findings. "
        "Keep summary at most 160 characters, and each claim and recommendation at most 100 characters. "
        "{\"verdict\":\"approve|request_changes|comment\",\"summary\":string,"
        "\"findings\":[{\"id\":string,\"severity\":\"blocker|major|minor|nit\","
        "\"path\":string|null,\"line\":integer|null,\"claim\":string,\"recommendation\":string}]}",
        "Public issue description:\n\n" + public_task + "\n\nInitial diff:\n\n" + initial_diff,
    )


def adjudicator_prompts(public_task: str, initial_diff: str, review: ReviewReport) -> tuple[str, str]:
    review_text = json.dumps(review_report_json(review), ensure_ascii=False, sort_keys=True)
    return (
        "You are the adjudicator. The workspace contains the initial patch and is writable. "
        "Use only the public task, initial diff, and structured review below. "
        "Hidden evaluator/tests are unavailable; do not search for or infer them. Apply only justified changes. "
        "You have at most one tool-enabled turn; the final turn has no tools and must return the JSON response. "
        "Return ONLY JSON, without Markdown. Keep summary at most 160 characters and each rationale at most 120 characters: {\"summary\":string,\"decisions\":[{"
        "\"finding_id\":string,\"decision\":\"accepted|rejected|not_actionable\",\"rationale\":string}]}. "
        "Provide exactly one decision for every finding.",
        "Public issue description:\n\n" + public_task + "\n\nInitial diff:\n\n" + initial_diff
        + "\n\nStructured review:\n\n" + review_text,
    )
