"""Core safety, validation, snapshot, and accounting primitives for the PR harness.

This module intentionally has no OpenRouter calls.  It is suitable for the
no-execute verification path and for local unit tests.
"""
from __future__ import annotations

import difflib
import fcntl
import hashlib
import json
import math
import os
import re
import shutil
import stat
import tempfile
import time
from pathlib import Path, PurePosixPath
from typing import Any, Iterable

# These are the exact OpenRouter IDs selected during preflight.  Canonical
# provider slugs remain provenance metadata only: sending them instead would
# be an unapproved model substitution.
MODEL_IDS = (
    "openai/gpt-6.1-sol",
    "anthropic/claude-sonnet-5.5",
    "google/gemini-3.8-flash",
)
REQUEST_ID_RE = re.compile(r"^[0-9a-f]{32}$")
FORBIDDEN_WORKSPACE_TOPLEVEL = {".git", ".harness", ".pr_review_harness", ".metadata"}
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$")
RUNTIME_LANGUAGES = frozenset({"python", "node", "dotnet"})


class HarnessError(RuntimeError):
    """A deterministic harness validation or safety error."""


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def manifest_freeze_hash(manifest: dict[str, Any]) -> str:
    """Hash the manifest's canonical JSON with its self-hash removed."""
    copy = dict(manifest)
    copy.pop("freeze_sha256", None)
    return hashlib.sha256(canonical_json_bytes(copy)).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise HarnessError(f"Cannot read JSON {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise HarnessError(f"JSON root must be an object: {path}")
    return data


def require_sha256(value: Any, field: str) -> str:
    if not isinstance(value, str) or not SHA256_RE.fullmatch(value):
        raise HarnessError(f"{field} must be a lowercase 64-character SHA-256")
    return value


def require_name(value: Any, field: str) -> str:
    if not isinstance(value, str) or not NAME_RE.fullmatch(value):
        raise HarnessError(f"{field} must be a safe name (letters, digits, _, ., -)")
    return value


def directed_pairs(models: Iterable[str] = MODEL_IDS) -> list[tuple[str, str]]:
    listed = list(models)
    return [(author, reviewer) for author in listed for reviewer in listed if author != reviewer]


def validate_config(config: dict[str, Any]) -> None:
    """Validate execution controls without opening network connections."""
    models = config.get("models")
    if not isinstance(models, list) or len(models) not in {2, 3}:
        raise HarnessError("config.models must contain two or three preselected models")
    ids = []
    for item in models:
        if not isinstance(item, dict) or not isinstance(item.get("id"), str):
            raise HarnessError("Each config.models entry must have an id")
        model_id = item["id"]
        ids.append(model_id)
        prices = item.get("prices")
        if not isinstance(prices, dict):
            raise HarnessError(f"config.models[{model_id}].prices is required")
        for key in ("input_per_million_usd", "output_per_million_usd"):
            value = prices.get(key)
            if not isinstance(value, (int, float)) or isinstance(value, bool) or value <= 0 or not math.isfinite(value):
                raise HarnessError(f"config.models[{model_id}].prices.{key} must be a positive number")
    if not set(ids).issubset(set(MODEL_IDS)) or len(set(ids)) != len(ids):
        raise HarnessError("config.models ids must be a unique subset of the pinned canonical OpenRouter model slugs")
    replicates = config.get("replicates", 3)
    if not isinstance(replicates, int) or isinstance(replicates, bool) or not 1 <= replicates <= 3:
        raise HarnessError("config.replicates must be an integer from 1 to 3")
    workers = config.get("workers", 1)
    if not isinstance(workers, int) or not 1 <= workers <= 2:
        raise HarnessError("config.workers must be an integer from 1 to 2")
    max_total = config.get("max_total_usd")
    if not isinstance(max_total, (int, float)) or isinstance(max_total, bool) or max_total <= 0 or not math.isfinite(max_total):
        raise HarnessError("config.max_total_usd must be a positive number")
    carryover = config.get("prior_cumulative_spend_usd", config.get("prior_aborted_attempt_spend_usd", 0.0))
    if (not isinstance(carryover, (int, float)) or isinstance(carryover, bool)
            or carryover < 0 or not math.isfinite(carryover) or carryover >= max_total):
        raise HarnessError("config.prior_aborted_attempt_spend_usd must be a finite non-negative amount below max_total_usd")
    prior_reservations = config.get("prior_unresolved_reservations", [])
    if not isinstance(prior_reservations, list):
        raise HarnessError("config.prior_unresolved_reservations must be an array")
    seen_reservations: set[str] = set()
    reserved_total = 0.0
    for index, item in enumerate(prior_reservations):
        if not isinstance(item, dict) or set(item) != {"request_id", "estimated_usd", "details", "reserved_at"}:
            raise HarnessError(f"config.prior_unresolved_reservations[{index}] has an invalid shape")
        request_id = item["request_id"]
        amount = item["estimated_usd"]
        if not isinstance(request_id, str) or not REQUEST_ID_RE.fullmatch(request_id) or request_id in seen_reservations:
            raise HarnessError(f"config.prior_unresolved_reservations[{index}].request_id is invalid or duplicated")
        if not isinstance(amount, (int, float)) or isinstance(amount, bool) or amount <= 0 or not math.isfinite(amount):
            raise HarnessError(f"config.prior_unresolved_reservations[{index}].estimated_usd must be positive and finite")
        if not isinstance(item["details"], dict):
            raise HarnessError(f"config.prior_unresolved_reservations[{index}].details must be an object")
        if (not isinstance(item["reserved_at"], (int, float)) or isinstance(item["reserved_at"], bool)
                or not math.isfinite(item["reserved_at"]) or item["reserved_at"] <= 0):
            raise HarnessError(f"config.prior_unresolved_reservations[{index}].reserved_at must be positive and finite")
        seen_reservations.add(request_id)
        reserved_total += float(amount)
    known_preflight = config.get("known_preflight_spend_usd", 0.0)
    if (not isinstance(known_preflight, (int, float)) or isinstance(known_preflight, bool)
            or not math.isfinite(known_preflight) or known_preflight < 0
            or float(known_preflight) + float(carryover) + reserved_total > max_total + 1e-12):
        raise HarnessError("Actual lifetime spend plus prior unresolved reservations exceeds max_total_usd")
    limits = config.get("limits")
    if not isinstance(limits, dict):
        raise HarnessError("config.limits is required")
    for role in ("author", "review", "adjudicate"):
        item = limits.get(role)
        if not isinstance(item, dict):
            raise HarnessError(f"config.limits.{role} is required")
        for key in ("max_turns", "max_input_tokens", "max_tokens", "timeout_seconds", "max_commands"):
            value = item.get(key)
            if not isinstance(value, int) or value <= 0:
                raise HarnessError(f"config.limits.{role}.{key} must be a positive integer")
        if "max_request_bytes" in item:
            value = item["max_request_bytes"]
            if not isinstance(value, int) or isinstance(value, bool) or value <= 0:
                raise HarnessError(f"config.limits.{role}.max_request_bytes must be a positive integer")
        max_tool_turns = item.get("max_tool_turns", item["max_turns"])
        max_tool_calls = item.get("max_tool_calls", item["max_commands"])
        if not isinstance(max_tool_turns, int) or isinstance(max_tool_turns, bool) or not 0 <= max_tool_turns <= item["max_turns"]:
            raise HarnessError(f"config.limits.{role}.max_tool_turns must be between zero and max_turns")
        if not isinstance(max_tool_calls, int) or isinstance(max_tool_calls, bool) or max_tool_calls < 0:
            raise HarnessError(f"config.limits.{role}.max_tool_calls must be a non-negative integer")
        value = item.get("max_cost_usd")
        if not isinstance(value, (int, float)) or isinstance(value, bool) or value <= 0 or not math.isfinite(value):
            raise HarnessError(f"config.limits.{role}.max_cost_usd must be a positive number")
        # A reservation must cover the largest selected provider's full
        # configured input/output allowance before any request is made.
        worst_case = max(
            (item["max_input_tokens"] * model["prices"]["input_per_million_usd"]
             + item["max_tokens"] * model["prices"]["output_per_million_usd"]) / 1_000_000
            for model in models
        )
        if value + 1e-12 < worst_case:
            raise HarnessError(
                f"config.limits.{role}.max_cost_usd (${value}) does not cover the "
                f"worst-case selected-model request (${worst_case:.8f})"
            )
    tool_limits = config.get("tool_limits", {})
    if not isinstance(tool_limits, dict):
        raise HarnessError("config.tool_limits must be an object")
    for key, default in (("output_chars", 8000), ("read_bytes", 24000), ("write_bytes", 100000), ("shell_timeout_seconds", 60)):
        value = tool_limits.get(key, default)
        if not isinstance(value, int) or value <= 0:
            raise HarnessError(f"config.tool_limits.{key} must be a positive integer")


def _validate_pinned_path(item: Any, field: str) -> None:
    if not isinstance(item, dict):
        raise HarnessError(f"{field} entries must be objects")
    source = item.get("source_path")
    mount = item.get("mount_path")
    if not isinstance(source, str) or not os.path.isabs(source):
        raise HarnessError(f"{field}.source_path must be absolute")
    if not isinstance(mount, str) or not mount.startswith("/evaluator/"):
        raise HarnessError(f"{field}.mount_path must be below /evaluator/")
    pure = PurePosixPath(mount)
    if ".." in pure.parts:
        raise HarnessError(f"{field}.mount_path may not contain ..")
    require_sha256(item.get("sha256"), f"{field}.sha256")


def _workspace_relative_path(value: Any, field: str) -> str:
    """Validate a relative path which will become a /workspace mount target."""
    if not isinstance(value, str) or not value:
        raise HarnessError(f"{field} must be a non-empty relative workspace path")
    pure = PurePosixPath(value)
    if pure.is_absolute() or not pure.parts or ".." in pure.parts:
        raise HarnessError(f"{field} must be a non-empty relative workspace path without ..")
    if pure.parts[0] in FORBIDDEN_WORKSPACE_TOPLEVEL:
        raise HarnessError(f"{field} addresses workspace metadata hidden from agents")
    return pure.as_posix()


def _dependency_subpath(value: Any, field: str) -> str:
    """Validate a dependency-relative mount source; '.' denotes its root."""
    if value == ".":
        return "."
    return _workspace_relative_path(value, field)


def _path_is_within(path: str, parent: str) -> bool:
    try:
        PurePosixPath(path).relative_to(PurePosixPath(parent))
        return True
    except ValueError:
        return False


def runtime_spec(issue: dict[str, Any]) -> dict[str, Any]:
    """Return the optional per-instance runtime spec, or a safe empty default.

    The result contains no arbitrary environment assignments. Runtime variables
    are derived later from these validated, frozen workspace-relative paths.
    """
    runtime = issue.get("runtime")
    if runtime is None:
        return {"language": None, "overlays": [], "runtime_root": None, "package_path": None,
                "path_prepend": [], "pythonpath_prepend": []}
    if not isinstance(runtime, dict):
        raise HarnessError("issue.runtime must be an object")
    return runtime


def _validate_runtime(runtime: Any, field: str, dependency_names: set[str]) -> None:
    if not isinstance(runtime, dict):
        raise HarnessError(f"{field} must be an object")
    expected = {"language", "overlays", "runtime_root", "package_path", "path_prepend", "pythonpath_prepend"}
    if set(runtime) != expected:
        raise HarnessError(f"{field} must contain exactly {', '.join(sorted(expected))}")
    language = runtime.get("language")
    if language not in RUNTIME_LANGUAGES:
        raise HarnessError(f"{field}.language must be one of {', '.join(sorted(RUNTIME_LANGUAGES))}")
    overlays = runtime.get("overlays")
    if not isinstance(overlays, list) or not overlays:
        raise HarnessError(f"{field}.overlays must be a non-empty array")
    seen_dependency_subpaths: set[tuple[str, str]] = set()
    seen_paths: list[str] = []
    for index, overlay in enumerate(overlays):
        item_field = f"{field}.overlays[{index}]"
        if not isinstance(overlay, dict) or set(overlay) not in (
            {"dependency", "workspace_path"},
            {"dependency", "source_subpath", "workspace_path"},
        ):
            raise HarnessError(f"{item_field} must contain dependency, workspace_path and optional source_subpath")
        dependency = overlay.get("dependency")
        if not isinstance(dependency, str) or dependency not in dependency_names:
            raise HarnessError(f"{item_field}.dependency must name an issue dependency")
        source_subpath = _dependency_subpath(overlay.get("source_subpath", "."), f"{item_field}.source_subpath")
        if (dependency, source_subpath) in seen_dependency_subpaths:
            raise HarnessError(f"{item_field} duplicates a dependency source subpath")
        seen_dependency_subpaths.add((dependency, source_subpath))
        workspace_path = _workspace_relative_path(overlay.get("workspace_path"), f"{item_field}.workspace_path")
        if any(_path_is_within(workspace_path, existing) or _path_is_within(existing, workspace_path) for existing in seen_paths):
            raise HarnessError(f"{item_field}.workspace_path overlaps another runtime overlay")
        seen_paths.append(workspace_path)

    root = runtime.get("runtime_root")
    if language in {"node", "dotnet"}:
        root = _workspace_relative_path(root, f"{field}.runtime_root")
        if not any(_path_is_within(root, path) for path in seen_paths):
            raise HarnessError(f"{field}.runtime_root must be within a runtime overlay")
    elif root is not None:
        raise HarnessError(f"{field}.runtime_root must be null for python")

    package_path = runtime.get("package_path")
    if language == "dotnet":
        package_path = _workspace_relative_path(package_path, f"{field}.package_path")
        if not any(_path_is_within(package_path, path) for path in seen_paths):
            raise HarnessError(f"{field}.package_path must be within a runtime overlay")
    elif package_path is not None:
        raise HarnessError(f"{field}.package_path must be null unless language is dotnet")

    for key in ("path_prepend", "pythonpath_prepend"):
        values = runtime.get(key)
        if not isinstance(values, list) or not all(isinstance(value, str) for value in values):
            raise HarnessError(f"{field}.{key} must be an array of paths")
        seen: set[str] = set()
        for index, value in enumerate(values):
            path = _workspace_relative_path(value, f"{field}.{key}[{index}]")
            if path in seen:
                raise HarnessError(f"{field}.{key} contains a duplicate path")
            seen.add(path)
            if not any(_path_is_within(path, overlay_path) for overlay_path in seen_paths):
                raise HarnessError(f"{field}.{key}[{index}] must be within a runtime overlay")


def runtime_overlay_paths(runtime: dict[str, Any] | None) -> tuple[str, ...]:
    """Return already-validated overlay paths for mount assembly and tool guards."""
    if not runtime or runtime.get("language") is None:
        return ()
    overlays = runtime.get("overlays")
    if not isinstance(overlays, list):
        raise HarnessError("Runtime overlays are malformed")
    paths: list[str] = []
    for overlay in overlays:
        if not isinstance(overlay, dict):
            raise HarnessError("Runtime overlay is malformed")
        paths.append(_workspace_relative_path(overlay.get("workspace_path"), "runtime overlay workspace_path"))
    return tuple(paths)


def runtime_environment(runtime: dict[str, Any] | None) -> dict[str, str]:
    """Derive a minimal offline runtime environment from a frozen runtime spec."""
    env = {
        "PATH": "/usr/local/bin:/usr/bin:/bin",
        "HOME": "/tmp",
        "LANG": "C.UTF-8",
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_COUNT": "1",
        "GIT_CONFIG_KEY_0": "safe.directory",
        "GIT_CONFIG_VALUE_0": "/workspace",
    }
    if not runtime or runtime.get("language") is None:
        return env
    language = runtime.get("language")
    prepend = runtime.get("path_prepend", [])
    pythonpath = runtime.get("pythonpath_prepend", [])
    if language not in RUNTIME_LANGUAGES or not isinstance(prepend, list) or not isinstance(pythonpath, list):
        raise HarnessError("Runtime spec is malformed")
    path_entries = ["/workspace/" + _workspace_relative_path(value, "runtime path_prepend") for value in prepend]
    if language == "node":
        root = _workspace_relative_path(runtime.get("runtime_root"), "runtime runtime_root")
        path_entries.insert(0, "/workspace/" + root + "/bin")
        env.update({
            "NPM_CONFIG_OFFLINE": "true",
            "NPM_CONFIG_AUDIT": "false",
            "NPM_CONFIG_FUND": "false",
            "NPM_CONFIG_UPDATE_NOTIFIER": "false",
            "npm_config_cache": "/tmp/npm-cache",
        })
    elif language == "dotnet":
        root = _workspace_relative_path(runtime.get("runtime_root"), "runtime runtime_root")
        absolute_root = "/workspace/" + root
        package_path = _workspace_relative_path(runtime.get("package_path"), "runtime package_path")
        path_entries.insert(0, absolute_root)
        env.update({
            "DOTNET_ROOT": absolute_root,
            "DOTNET_CLI_HOME": "/tmp/dotnet-home",
            "DOTNET_CLI_TELEMETRY_OPTOUT": "1",
            "DOTNET_NOLOGO": "1",
            "DOTNET_SKIP_FIRST_TIME_EXPERIENCE": "1",
            "NUGET_HTTP_CACHE_PATH": "/tmp/nuget-http-cache",
            "NUGET_PACKAGES": "/workspace/" + package_path,
            "NUGET_XMLDOC_MODE": "skip",
        })
    elif language == "python":
        env.update({"PIP_NO_INDEX": "1", "PIP_DISABLE_PIP_VERSION_CHECK": "1", "PYTHONDONTWRITEBYTECODE": "1"})
    else:  # Defensive: this is normally covered by validation before execution.
        raise HarnessError("Runtime language is invalid")
    if path_entries:
        env["PATH"] = ":".join(path_entries + [env["PATH"]])
    if pythonpath:
        env["PYTHONPATH"] = ":".join(
            "/workspace/" + _workspace_relative_path(value, "runtime pythonpath_prepend") for value in pythonpath
        )
    return env


def validate_manifest(manifest: dict[str, Any]) -> None:
    """Validate the frozen manifest schema without reading any corpus asset."""
    require_sha256(manifest.get("freeze_sha256"), "manifest.freeze_sha256")
    expected = manifest_freeze_hash(manifest)
    if manifest["freeze_sha256"] != expected:
        raise HarnessError("manifest.freeze_sha256 does not match canonical manifest content")
    issues = manifest.get("issues")
    if not isinstance(issues, list) or not issues:
        raise HarnessError("manifest.issues must be a non-empty array")
    seen: set[str] = set()
    for index, issue in enumerate(issues):
        path = f"manifest.issues[{index}]"
        if not isinstance(issue, dict):
            raise HarnessError(f"{path} must be an object")
        issue_id = require_name(issue.get("id"), f"{path}.id")
        if issue_id in seen:
            raise HarnessError(f"Duplicate issue id: {issue_id}")
        seen.add(issue_id)
        if not isinstance(issue.get("source_path"), str) or not os.path.isabs(issue["source_path"]):
            raise HarnessError(f"{path}.source_path must be absolute")
        require_sha256(issue.get("source_tree_sha256"), f"{path}.source_tree_sha256")
        source_links = issue.get("source_allow_internal_relative_symlinks", False)
        if not isinstance(source_links, bool):
            raise HarnessError(f"{path}.source_allow_internal_relative_symlinks must be boolean")
        task = issue.get("public_task")
        if not isinstance(task, str) or not task.strip() or len(task.encode("utf-8")) > 100_000:
            raise HarnessError(f"{path}.public_task must be non-empty UTF-8 text up to 100000 bytes")
        dependencies = issue.get("dependencies", [])
        if not isinstance(dependencies, list):
            raise HarnessError(f"{path}.dependencies must be an array")
        dep_names: set[str] = set()
        for dindex, dep in enumerate(dependencies):
            if not isinstance(dep, dict):
                raise HarnessError(f"{path}.dependencies[{dindex}] must be an object")
            name = require_name(dep.get("name"), f"{path}.dependencies[{dindex}].name")
            if name in dep_names:
                raise HarnessError(f"Duplicate dependency name {name} for issue {issue_id}")
            dep_names.add(name)
            if not isinstance(dep.get("source_path"), str) or not os.path.isabs(dep["source_path"]):
                raise HarnessError(f"{path}.dependencies[{dindex}].source_path must be absolute")
            require_sha256(dep.get("tree_sha256"), f"{path}.dependencies[{dindex}].tree_sha256")
            links = dep.get("allow_internal_relative_symlinks", False)
            if not isinstance(links, bool):
                raise HarnessError(f"{path}.dependencies[{dindex}].allow_internal_relative_symlinks must be boolean")
        if "runtime" in issue:
            _validate_runtime(issue["runtime"], f"{path}.runtime", dep_names)
        evaluator = issue.get("evaluator")
        if not isinstance(evaluator, dict):
            raise HarnessError(f"{path}.evaluator is required")
        command = evaluator.get("command")
        if not isinstance(command, list) or not command or not all(isinstance(x, str) and x for x in command):
            raise HarnessError(f"{path}.evaluator.command must be a non-empty string array")
        assets = evaluator.get("pinned_paths")
        if not isinstance(assets, list) or not assets:
            raise HarnessError(f"{path}.evaluator.pinned_paths must be a non-empty array")
        mounts: set[str] = set()
        for aindex, asset in enumerate(assets):
            _validate_pinned_path(asset, f"{path}.evaluator.pinned_paths[{aindex}]")
            replace_existing = asset.get("replace_existing", False)
            if not isinstance(replace_existing, bool):
                raise HarnessError(f"{path}.evaluator.pinned_paths[{aindex}].replace_existing must be boolean")
            if "workspace_path" in asset:
                _workspace_relative_path(asset["workspace_path"], f"{path}.evaluator.pinned_paths[{aindex}].workspace_path")
            mount = asset["mount_path"]
            if mount in mounts:
                raise HarnessError(f"Duplicate evaluator mount path: {mount}")
            mounts.add(mount)
        timeout = evaluator.get("timeout_seconds", 120)
        if not isinstance(timeout, int) or timeout <= 0:
            raise HarnessError(f"{path}.evaluator.timeout_seconds must be a positive integer")


def _validate_internal_relative_symlink(root: Path, candidate: Path) -> str:
    """Return a safe relative target, rejecting every link that escapes a tree."""
    target = os.readlink(candidate)
    if not target or os.path.isabs(target):
        raise HarnessError(f"Frozen symlink must have a non-empty relative target: {candidate}")
    try:
        resolved = (candidate.parent / target).resolve(strict=True)
    except (OSError, RuntimeError) as exc:
        raise HarnessError(f"Frozen symlink has an unresolved target: {candidate}") from exc
    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise HarnessError(f"Frozen symlink escapes its declared tree: {candidate}") from exc
    return target


def internal_relative_symlink_map(root: Path) -> dict[str, str]:
    """Return every validated internal link as a deterministic relative-path map."""
    if root.is_symlink():
        raise HarnessError(f"Frozen tree root may not be a symlink: {root}")
    root = root.resolve(strict=True)
    if not root.is_dir():
        raise HarnessError(f"Expected a directory: {root}")
    links: dict[str, str] = {}
    for current, dirs, files in os.walk(root, topdown=True, followlinks=False):
        dirs.sort()
        files.sort()
        current_path = Path(current)
        for name in dirs + files:
            candidate = current_path / name
            if candidate.is_symlink():
                links[candidate.relative_to(root).as_posix()] = _validate_internal_relative_symlink(root, candidate)
    return links


def _iter_tree_entries(
    root: Path,
    *,
    allow_internal_relative_symlinks: bool = False,
) -> Iterable[tuple[str, Path]]:
    """Yield deterministic entries, optionally allowing verified internal links."""
    root = root.resolve()
    if not root.is_dir():
        raise HarnessError(f"Expected a directory: {root}")
    for current, dirs, files in os.walk(root, topdown=True, followlinks=False):
        dirs.sort()
        files.sort()
        current_path = Path(current)
        for name in list(dirs):
            candidate = current_path / name
            if candidate.is_symlink():
                if not allow_internal_relative_symlinks:
                    raise HarnessError(f"Symlinks are forbidden in frozen trees: {candidate}")
                _validate_internal_relative_symlink(root, candidate)
                yield candidate.relative_to(root).as_posix(), candidate
        for name in files:
            candidate = current_path / name
            if candidate.is_symlink():
                if not allow_internal_relative_symlinks:
                    raise HarnessError(f"Symlinks are forbidden in frozen trees: {candidate}")
                _validate_internal_relative_symlink(root, candidate)
                yield candidate.relative_to(root).as_posix(), candidate
                continue
            if not candidate.is_file():
                raise HarnessError(f"Only regular files are allowed in frozen trees: {candidate}")
            yield candidate.relative_to(root).as_posix(), candidate


def tree_sha256(root: Path, *, allow_internal_relative_symlinks: bool = False) -> str:
    """Return a reproducible hash for frozen regular files and allowed links."""
    root = root.resolve(strict=True)
    h = hashlib.sha256()
    for relative, candidate in _iter_tree_entries(root, allow_internal_relative_symlinks=allow_internal_relative_symlinks):
        if candidate.is_symlink():
            target = _validate_internal_relative_symlink(root, candidate)
            h.update(b"L\\0" + relative.encode("utf-8") + b"\\0" + target.encode("utf-8") + b"\\0")
            continue
        h.update(b"F\\0" + relative.encode("utf-8") + b"\\0")
        with candidate.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                h.update(chunk)
        h.update(b"\\0")
    return h.hexdigest()


def file_or_tree_sha256(path: Path) -> str:
    """Hash a pinned regular file or a tree, rejecting symlinks in either case."""
    if path.is_symlink():
        raise HarnessError(f"Symlink is not a valid pinned asset: {path}")
    if path.is_dir():
        return tree_sha256(path)
    if path.is_file():
        h = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()
    raise HarnessError(f"Pinned asset is neither a regular file nor directory: {path}")


def _is_relative_to(path: Path, ancestor: Path) -> bool:
    try:
        path.relative_to(ancestor)
        return True
    except ValueError:
        return False


def validate_issue_files(issue: dict[str, Any]) -> None:
    """Verify corpus/dependency/evaluator pins and prevent evaluator overlap."""
    source_path = Path(issue["source_path"])
    if source_path.is_symlink():
        raise HarnessError("Source root may not be a symlink")
    source = source_path.resolve(strict=True)
    allow_source_links = issue.get("source_allow_internal_relative_symlinks", False)
    if tree_sha256(source, allow_internal_relative_symlinks=allow_source_links) != issue["source_tree_sha256"]:
        raise HarnessError(f"Source tree digest mismatch for issue {issue['id']}")
    runtime = runtime_spec(issue)
    overlay_paths = runtime_overlay_paths(runtime)
    for overlay_path in overlay_paths:
        target = source.joinpath(*PurePosixPath(overlay_path).parts)
        if target.exists() or target.is_symlink():
            raise HarnessError(f"Runtime overlay target must be absent from C0 source: {overlay_path}")
    evaluator_roots: list[Path] = []
    evaluator_workspace_paths: list[str] = []
    for asset in issue["evaluator"]["pinned_paths"]:
        asset_path = Path(asset["source_path"])
        if asset_path.is_symlink():
            raise HarnessError("Evaluator asset root may not be a symlink")
        item = asset_path.resolve(strict=True)
        if file_or_tree_sha256(item) != asset["sha256"]:
            raise HarnessError(f"Evaluator asset digest mismatch: {item}")
        evaluator_roots.append(item)
        if _is_relative_to(item, source) or _is_relative_to(source, item):
            raise HarnessError("Evaluator assets must be physically separate from the agent C0 source tree")
        workspace_path = asset.get("workspace_path")
        if workspace_path is not None:
            workspace_path = _workspace_relative_path(workspace_path, "evaluator asset workspace_path")
            if any(_path_is_within(workspace_path, other) or _path_is_within(other, workspace_path)
                   for other in evaluator_workspace_paths):
                raise HarnessError("Evaluator workspace asset paths may not overlap")
            if any(_path_is_within(workspace_path, overlay) or _path_is_within(overlay, workspace_path)
                   for overlay in overlay_paths):
                raise HarnessError("Evaluator workspace asset may not overlap a runtime overlay")
            target = source.joinpath(*PurePosixPath(workspace_path).parts)
            replace_existing = asset.get("replace_existing", False)
            if (target.exists() or target.is_symlink()) and not replace_existing:
                raise HarnessError(f"Evaluator workspace asset target must be absent from C0 source: {workspace_path}")
            evaluator_workspace_paths.append(workspace_path)
    for dependency in issue.get("dependencies", []):
        dependency_path = Path(dependency["source_path"])
        if dependency_path.is_symlink():
            raise HarnessError("Dependency root may not be a symlink")
        path = dependency_path.resolve(strict=True)
        allow_dependency_links = dependency.get("allow_internal_relative_symlinks", False)
        if tree_sha256(path, allow_internal_relative_symlinks=allow_dependency_links) != dependency["tree_sha256"]:
            raise HarnessError(f"Dependency tree digest mismatch: {path}")
        for evaluator_root in evaluator_roots:
            if _is_relative_to(path, evaluator_root) or _is_relative_to(evaluator_root, path):
                raise HarnessError("Agent dependencies may not overlap evaluator assets")


def copy_regular_tree(
    source: Path,
    destination: Path,
    *,
    allow_internal_relative_symlinks: bool = False,
) -> None:
    """Copy a frozen tree after inspection, preserving only declared safe links."""
    if source.is_symlink():
        raise HarnessError(f"Source root may not be a symlink: {source}")
    source = source.resolve(strict=True)
    if destination.exists():
        raise HarnessError(f"Destination already exists: {destination}")
    # Inspect first so copy does not dereference a hostile source symlink.
    entries = list(_iter_tree_entries(source, allow_internal_relative_symlinks=allow_internal_relative_symlinks))
    destination.mkdir(parents=True)
    for relative, item in entries:
        if relative.split("/", 1)[0] in FORBIDDEN_WORKSPACE_TOPLEVEL:
            continue
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        if item.is_symlink():
            os.symlink(_validate_internal_relative_symlink(source, item), target)
        else:
            shutil.copy2(item, target, follow_symlinks=False)
    os.chmod(destination, 0o777)
    for current, dirs, files in os.walk(destination):
        os.chmod(current, 0o777)
        for filename in files:
            # Preserve executability while allowing the unprivileged sandbox user to edit.
            p = Path(current) / filename
            if p.is_symlink():
                continue
            mode = p.stat().st_mode
            os.chmod(p, mode | stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IWGRP | stat.S_IROTH | stat.S_IWOTH)


def copy_readonly_regular_tree(
    source: Path,
    destination: Path,
    *,
    allow_internal_relative_symlinks: bool = False,
) -> None:
    """Stage an immutable dependency, preserving only verified internal links."""
    copy_regular_tree(source, destination, allow_internal_relative_symlinks=allow_internal_relative_symlinks)
    for current, dirs, files in os.walk(destination, topdown=True, followlinks=False):
        current_path = Path(current)
        if current_path.is_symlink():
            raise HarnessError(f"Symlink appeared while staging dependency: {current_path}")
        os.chmod(current_path, 0o555)
        for filename in files:
            candidate = current_path / filename
            if candidate.is_symlink():
                continue
            mode = stat.S_IMODE(candidate.stat().st_mode)
            os.chmod(candidate, 0o555 if mode & 0o111 else 0o444)


def stage_dependencies(
    dependencies: dict[str, Path],
    destination: Path,
    *,
    expected_tree_sha256: dict[str, str] | None = None,
    allow_internal_relative_symlinks: dict[str, bool] | None = None,
) -> dict[str, Path]:
    """Copy all runtime dependencies privately before any agent/evaluator mount.

    Frozen source dependency roots are never mounted directly: this closes both
    symlink races and host-side source mutation between tool turns.
    """
    if destination.exists():
        raise HarnessError(f"Dependency staging destination already exists: {destination}")
    if expected_tree_sha256 is not None:
        if set(expected_tree_sha256) != set(dependencies):
            raise HarnessError("Dependency staging hashes must cover exactly the mounted dependencies")
        for name, digest in expected_tree_sha256.items():
            require_sha256(digest, f"dependency staging hash for {name}")
    if allow_internal_relative_symlinks is None:
        allow_internal_relative_symlinks = {name: False for name in dependencies}
    if set(allow_internal_relative_symlinks) != set(dependencies) or not all(
        isinstance(value, bool) for value in allow_internal_relative_symlinks.values()
    ):
        raise HarnessError("Dependency symlink policy must cover exactly the mounted dependencies with booleans")
    destination.mkdir(parents=True, mode=0o700)
    staged: dict[str, Path] = {}
    for name, source in sorted(dependencies.items()):
        require_name(name, "dependency name")
        target = destination / name
        allow_links = allow_internal_relative_symlinks[name]
        copy_readonly_regular_tree(source, target, allow_internal_relative_symlinks=allow_links)
        if expected_tree_sha256 is not None and tree_sha256(
            target, allow_internal_relative_symlinks=allow_links
        ) != expected_tree_sha256[name]:
            raise HarnessError(f"Staged dependency digest mismatch: {name}")
        staged[name] = target
    return staged


def prepare_runtime_workspace(workspace: Path, runtime: dict[str, Any] | None) -> None:
    """Create empty mount points for read-only runtime overlays before sandboxing."""
    workspace = workspace.resolve(strict=True)
    for overlay_path in runtime_overlay_paths(runtime):
        target = workspace.joinpath(*PurePosixPath(overlay_path).parts)
        if target.exists() or target.is_symlink():
            raise HarnessError(f"Runtime overlay mount point is not absent: {overlay_path}")
        target.parent.mkdir(parents=True, exist_ok=True)
        # Re-inspect after mkdir: an untrusted workspace must never direct us via a link.
        safe_workspace_path(workspace, target.relative_to(workspace).as_posix())
        target.mkdir()


def copy_pinned_asset(source: Path, evaluator_root: Path, mount_path: str) -> None:
    """Copy a validated evaluator asset into a private evaluator-only staging root."""
    rel = PurePosixPath(mount_path).relative_to("/evaluator")
    destination = evaluator_root.joinpath(*rel.parts)
    if source.is_symlink():
        raise HarnessError(f"Evaluator asset root may not be a symlink: {source}")
    source = source.resolve(strict=True)
    if source.is_dir():
        copy_regular_tree(source, destination)
    else:
        if source.is_symlink() or not source.is_file():
            raise HarnessError(f"Evaluator asset is not a regular file: {source}")
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination, follow_symlinks=False)


def assert_workspace_hygiene(
    workspace: Path,
    *,
    allowed_internal_relative_symlinks: dict[str, str] | None = None,
    allow_synthetic_git: bool = False,
) -> None:
    """Reject metadata and links except an unchanged source baseline and optional synthetic Git directory."""
    workspace = workspace.resolve(strict=True)
    for name in FORBIDDEN_WORKSPACE_TOPLEVEL:
        if name == ".git" and allow_synthetic_git:
            git_dir = workspace / ".git"
            if git_dir.exists() and (git_dir.is_symlink() or not git_dir.is_dir()):
                raise HarnessError("Synthetic Git metadata must be a regular workspace directory")
            continue
        if (workspace / name).exists() or (workspace / name).is_symlink():
            raise HarnessError(f"Agent created or exposed forbidden workspace metadata: {name}")
    if allowed_internal_relative_symlinks is None:
        # This catches any agent-created link before a host operation could follow it.
        list(_iter_tree_entries(workspace))
        return
    if not isinstance(allowed_internal_relative_symlinks, dict) or not all(
        isinstance(path, str) and isinstance(target, str)
        for path, target in allowed_internal_relative_symlinks.items()
    ):
        raise HarnessError("Allowed symlink baseline is malformed")
    observed = internal_relative_symlink_map(workspace)
    if observed != allowed_internal_relative_symlinks:
        raise HarnessError("Workspace symlink set differs from the frozen source baseline")
    list(_iter_tree_entries(workspace, allow_internal_relative_symlinks=True))


def safe_workspace_path(workspace: Path, requested: str, *, allow_root: bool = False) -> Path:
    """Resolve only a non-symlink, relative path whose entire prefix is in workspace."""
    if not isinstance(requested, str) or not requested:
        raise HarnessError("Tool path must be a non-empty string")
    pure = PurePosixPath(requested)
    if pure.is_absolute() or ".." in pure.parts:
        raise HarnessError("Tool paths must be relative and may not contain ..")
    if pure.parts and pure.parts[0] in FORBIDDEN_WORKSPACE_TOPLEVEL:
        raise HarnessError("Tool path addresses metadata hidden from agents")
    root = workspace.resolve(strict=True)
    candidate = root.joinpath(*pure.parts)
    if candidate == root and not allow_root:
        raise HarnessError("Workspace root is not a valid file path for this tool")
    # Do not use Path.resolve on an untrusted leaf: inspect each existing prefix instead.
    current = root
    for part in pure.parts:
        current = current / part
        try:
            entry = os.lstat(current)
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(entry.st_mode):
            raise HarnessError(f"Symlinks are not permitted in agent tool paths: {requested}")
    absolute = candidate.absolute()
    if not _is_relative_to(absolute, root):
        raise HarnessError("Tool path escaped workspace")
    return absolute


def snapshot_tree(
    root: Path,
    *,
    allow_internal_relative_symlinks: bool = False,
) -> dict[str, dict[str, Any]]:
    """Create a Git-independent snapshot including opted-in immutable links."""
    root = root.resolve(strict=True)
    entries: dict[str, dict[str, Any]] = {}
    for relative, path in _iter_tree_entries(root, allow_internal_relative_symlinks=allow_internal_relative_symlinks):
        if relative == ".git" or relative.startswith(".git/"):
            continue
        if path.is_symlink():
            entries[relative] = {
                "symlink": _validate_internal_relative_symlink(root, path),
                "mode": stat.S_IMODE(path.lstat().st_mode),
            }
            continue
        data = path.read_bytes()
        item: dict[str, Any] = {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data), "mode": stat.S_IMODE(path.stat().st_mode)}
        if len(data) <= 1_000_000:
            try:
                item["text"] = data.decode("utf-8")
            except UnicodeDecodeError:
                pass
        entries[relative] = item
    return entries


def render_snapshot_patch(before: dict[str, dict[str, Any]], after: dict[str, dict[str, Any]], label_a: str, label_b: str) -> str:
    """Render a bounded unified text patch plus explicit binary change metadata."""
    chunks: list[str] = []
    for name in sorted(set(before) | set(after)):
        old, new = before.get(name), after.get(name)
        if old == new:
            continue
        if old is not None and new is not None and "text" in old and "text" in new:
            chunks.extend(difflib.unified_diff(old["text"].splitlines(keepends=True), new["text"].splitlines(keepends=True), fromfile=f"{label_a}/{name}", tofile=f"{label_b}/{name}"))
        elif old is None and new is not None and "text" in new:
            chunks.extend(difflib.unified_diff([], new["text"].splitlines(keepends=True), fromfile="/dev/null", tofile=f"{label_b}/{name}"))
        elif new is None and old is not None and "text" in old:
            chunks.extend(difflib.unified_diff(old["text"].splitlines(keepends=True), [], fromfile=f"{label_a}/{name}", tofile="/dev/null"))
        else:
            chunks.append("# BINARY_OR_LARGE_FILE_CHANGE " + name + " old=" + (old or {}).get("sha256", "absent") + " new=" + (new or {}).get("sha256", "absent") + "\n")
    return "".join(chunks)


def atomic_write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".tmp-", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, sort_keys=True, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class CostLedger:
    """A flock-protected global reservation ledger, safe for up to two workers."""

    def __init__(self, root: Path, max_total_usd: float, *, initial_spend_usd: float = 0.0,
                 initial_reservations: dict[str, dict[str, Any]] | None = None) -> None:
        self.root = root
        self.path = root / "spend_ledger.json"
        self.lock_path = root / ".spend.lock"
        self.max_total_usd = float(max_total_usd)
        self.initial_spend_usd = float(initial_spend_usd)
        self.initial_reservations = dict(initial_reservations or {})
        initial_reserved = sum(float(item.get("estimated_usd", 0.0)) for item in self.initial_reservations.values())
        if (not math.isfinite(self.max_total_usd) or self.max_total_usd <= 0
                or not math.isfinite(self.initial_spend_usd) or self.initial_spend_usd < 0
                or self.initial_spend_usd + initial_reserved > self.max_total_usd
                or any(not REQUEST_ID_RE.fullmatch(key) or not isinstance(value, dict)
                       or not isinstance(value.get("estimated_usd"), (int, float))
                       or isinstance(value.get("estimated_usd"), bool) or value["estimated_usd"] <= 0
                       or not math.isfinite(value["estimated_usd"]) for key, value in self.initial_reservations.items())):
            raise HarnessError("Invalid ledger ceiling or initial spend")
        self.root.mkdir(parents=True, exist_ok=True)

    def _load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {
                "max_total_usd": self.max_total_usd,
                "actual_usd": self.initial_spend_usd,
                "initial_preflight_usd": self.initial_spend_usd,
                "reservations": self.initial_reservations,
                "events": ([{"event": "initialize", "actual_usd": self.initial_spend_usd, "at": time.time()}]
                           if self.initial_spend_usd else []) + [
                               {"event": "carryover_reservation", "request_id": key,
                                "estimated_usd": value["estimated_usd"], "details": value.get("details", {}),
                                "at": value.get("reserved_at", time.time())}
                               for key, value in self.initial_reservations.items()
                           ],
            }
        value = load_json(self.path)
        if value.get("max_total_usd") != self.max_total_usd:
            raise HarnessError("Existing spend ledger max_total_usd differs from config")
        if value.get("initial_preflight_usd", 0.0) != self.initial_spend_usd:
            raise HarnessError("Existing spend ledger initial preflight spend differs from authorization")
        return value

    def _locked(self):
        self.lock_path.touch(exist_ok=True)
        handle = self.lock_path.open("r+")
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        return handle

    def reserve(self, request_id: str, estimated_usd: float, details: dict[str, Any]) -> None:
        if estimated_usd <= 0 or not math.isfinite(estimated_usd):
            raise HarnessError("Request cost estimate must be finite and positive")
        handle = self._locked()
        try:
            ledger = self._load()
            reservations = ledger.setdefault("reservations", {})
            if request_id in reservations:
                raise HarnessError(f"Duplicate cost reservation: {request_id}")
            outstanding = sum(float(v["estimated_usd"]) for v in reservations.values())
            projected = float(ledger.get("actual_usd", 0.0)) + outstanding + estimated_usd
            if projected > self.max_total_usd + 1e-12:
                raise HarnessError(f"Spend guard stop: projected ${projected:.6f} exceeds ${self.max_total_usd:.6f}")
            reservations[request_id] = {"estimated_usd": estimated_usd, "details": details, "reserved_at": time.time()}
            ledger.setdefault("events", []).append({"event": "reserve", "request_id": request_id, "estimated_usd": estimated_usd, "at": time.time()})
            atomic_write_json(self.path, ledger)
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            handle.close()

    def settle(self, request_id: str, actual_usd: float) -> None:
        if actual_usd < 0 or not math.isfinite(actual_usd):
            raise HarnessError("Actual cost must be finite and non-negative")
        handle = self._locked()
        try:
            ledger = self._load()
            reservation = ledger.setdefault("reservations", {}).pop(request_id, None)
            if reservation is None:
                raise HarnessError(f"Cannot settle missing reservation: {request_id}")
            if actual_usd > float(reservation["estimated_usd"]) + 1e-12:
                raise HarnessError("Returned cost exceeded the pre-request worst-case reservation")
            projected = float(ledger.get("actual_usd", 0.0)) + actual_usd + sum(
                float(v["estimated_usd"]) for v in ledger["reservations"].values()
            )
            if projected > self.max_total_usd + 1e-12:
                raise HarnessError("Settling this request would exceed the authorized total")
            ledger["actual_usd"] = float(ledger.get("actual_usd", 0.0)) + actual_usd
            ledger.setdefault("events", []).append({"event": "settle", "request_id": request_id, "estimated_usd": reservation["estimated_usd"], "actual_usd": actual_usd, "at": time.time()})
            atomic_write_json(self.path, ledger)
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            handle.close()

    def cancel(self, request_id: str, reason: str) -> None:
        handle = self._locked()
        try:
            ledger = self._load()
            reservation = ledger.setdefault("reservations", {}).pop(request_id, None)
            if reservation is not None:
                ledger.setdefault("events", []).append({"event": "cancel", "request_id": request_id, "estimated_usd": reservation["estimated_usd"], "reason": reason, "at": time.time()})
                atomic_write_json(self.path, ledger)
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            handle.close()
