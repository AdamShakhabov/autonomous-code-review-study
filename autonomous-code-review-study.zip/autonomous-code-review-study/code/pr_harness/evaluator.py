"""Hidden evaluator staging and execution.

The evaluator is intentionally data-driven: a manifest supplies its pinned
assets and exact command.  This code never infers test frameworks, filenames,
or commands from repository contents.
"""
from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path, PurePosixPath
import selectors
import shutil
import subprocess
import time
from typing import Any

from .core import (
    HarnessError,
    copy_pinned_asset,
    copy_regular_tree,
    file_or_tree_sha256,
    internal_relative_symlink_map,
    prepare_runtime_workspace,
    runtime_spec,
)
from .isolation import bounded_text, build_bwrap_command


@dataclass(frozen=True)
class EvaluatorStage:
    """Private evaluator inputs; neither path is ever mounted for a model agent."""

    workspace: Path
    evaluator_root: Path


def _copy_asset_to_workspace(
    source: Path,
    workspace: Path,
    workspace_path: str,
    *,
    replace_existing: bool = False,
) -> None:
    """Copy a pinned asset only into a private evaluator workspace."""
    destination = workspace.joinpath(*Path(workspace_path).parts)
    if destination.exists() or destination.is_symlink():
        if not replace_existing:
            raise HarnessError(f"Evaluator workspace asset destination already exists: {workspace_path}")
        if destination.is_symlink() or not destination.is_file():
            raise HarnessError(f"Evaluator replacement destination must be an existing regular file: {workspace_path}")
        destination.unlink()
    if source.is_symlink():
        raise HarnessError(f"Evaluator asset root may not be a symlink: {source}")
    source = source.resolve(strict=True)
    if source.is_dir():
        copy_regular_tree(source, destination)
        return
    if not source.is_file():
        raise HarnessError(f"Evaluator asset is not a regular file: {source}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination, follow_symlinks=False)


def stage_hidden_evaluator(issue: dict[str, Any], agent_workspace: Path, destination: Path) -> EvaluatorStage:
    """Construct an evaluator-only copy of C1/C2 and inject optional hidden assets.

    The agent workspace is copied rather than mounted. This permits test runners
    to build under their private /workspace while preserving the reviewed C1/C2
    tree read-only and undisclosed to later model stages.
    """
    if destination.exists():
        raise HarnessError(f"Evaluator staging destination already exists: {destination}")
    destination.mkdir(parents=True, mode=0o700)
    private_workspace = destination / "workspace"
    copy_regular_tree(
        agent_workspace,
        private_workspace,
        allow_internal_relative_symlinks=issue.get("source_allow_internal_relative_symlinks", False),
    )
    runtime = runtime_spec(issue)
    prepare_runtime_workspace(private_workspace, runtime)
    evaluator_root = destination / "assets"
    evaluator_root.mkdir(mode=0o700)
    for asset in issue["evaluator"]["pinned_paths"]:
        source = Path(asset["source_path"])
        copy_pinned_asset(source, evaluator_root, asset["mount_path"])
        staged_asset = evaluator_root.joinpath(*PurePosixPath(asset["mount_path"]).relative_to("/evaluator").parts)
        if file_or_tree_sha256(staged_asset) != asset["sha256"]:
            raise HarnessError(f"Staged evaluator asset digest mismatch: {asset['mount_path']}")
        if "workspace_path" in asset:
            _copy_asset_to_workspace(
                staged_asset,
                private_workspace,
                asset["workspace_path"],
                replace_existing=asset.get("replace_existing", False),
            )
    return EvaluatorStage(workspace=private_workspace, evaluator_root=evaluator_root)


def _capture_bounded(process: subprocess.Popen[bytes], timeout_seconds: int, output_chars: int) -> tuple[int | None, str, str, bool]:
    """Drain both pipes while retaining only a bounded prefix, then enforce timeout."""
    if process.stdout is None or process.stderr is None:
        raise HarnessError("Evaluator process pipes were not configured")
    selector = selectors.DefaultSelector()
    selector.register(process.stdout, selectors.EVENT_READ, "stdout")
    selector.register(process.stderr, selectors.EVENT_READ, "stderr")
    chunks: dict[str, bytearray] = {"stdout": bytearray(), "stderr": bytearray()}
    deadline = time.monotonic() + timeout_seconds
    timed_out = False
    while selector.get_map():
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            if not timed_out:
                timed_out = True
                process.kill()
            remaining = 1.0
        for key, _ in selector.select(max(0.0, remaining)):
            stream = key.fileobj
            chunk = os.read(stream.fileno(), 65536)
            if not chunk:
                selector.unregister(stream)
                continue
            held = chunks[key.data]
            # Keep enough bytes for a character-bounded final representation;
            # discard excess while continuing to drain the child pipe.
            if len(held) < output_chars * 4 + 4096:
                held.extend(chunk[: output_chars * 4 + 4096 - len(held)])
        if process.poll() is not None:
            # Select once more until both EOFs close.
            continue
    selector.close()
    try:
        returncode = process.wait(timeout=2)
    except subprocess.TimeoutExpired:
        process.kill()
        returncode = process.wait(timeout=2)
    stdout = bounded_text(bytes(chunks["stdout"]).decode("utf-8", "replace"), output_chars)
    stderr = bounded_text(bytes(chunks["stderr"]).decode("utf-8", "replace"), output_chars)
    return returncode, stdout, stderr, timed_out


def run_hidden_evaluator(
    *,
    issue: dict[str, Any],
    dependencies: dict[str, Path],
    staged: EvaluatorStage,
    output_dir: Path,
    output_chars: int,
) -> dict[str, Any]:
    """Run exactly manifest.evaluator.command; no test discovery or fallback command exists."""
    evaluator = issue["evaluator"]
    command = evaluator["command"]
    timeout = evaluator["timeout_seconds"]
    if output_dir.exists():
        raise HarnessError(f"Evaluator output destination already exists: {output_dir}")
    output_dir.mkdir(parents=True, mode=0o700)
    # Bubblewrap executes as its unprivileged sandbox identity. Its writable
    # /workspace is a private copy; the actual agent workspace is not mounted.
    os.chmod(output_dir, 0o777)
    bwrap = build_bwrap_command(
        workspace=staged.workspace,
        dependencies=dependencies,
        writable_workspace=True,
        evaluator_root=staged.evaluator_root,
        output_dir=output_dir,
        program=command,
        runtime=runtime_spec(issue),
        private_evaluator_workspace=True,
        allowed_internal_relative_symlinks=(
            internal_relative_symlink_map(staged.workspace)
            if issue.get("source_allow_internal_relative_symlinks", False) else None
        ),
    )
    started = time.monotonic()
    process = subprocess.Popen(
        bwrap,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd="/",
        env={"PATH": "/usr/bin:/bin", "HOME": "/nonexistent", "LANG": "C.UTF-8"},
    )
    returncode, stdout, stderr, timed_out = _capture_bounded(process, timeout, output_chars)
    if timed_out:
        outcome = "timeout"
    elif returncode == 0:
        outcome = "pass"
    else:
        outcome = "fail"
    return {
        "outcome": outcome,
        "returncode": returncode,
        "timeout": timed_out,
        "stdout": stdout,
        "stderr": stderr,
        "elapsed_seconds": round(time.monotonic() - started, 4),
        "command_source": "manifest.evaluator.command",
    }
