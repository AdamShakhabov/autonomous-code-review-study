"""Strict OpenRouter chat-completions transport.

The module performs no request at import time.  Credentials are read only inside
``complete`` immediately before an explicitly requested HTTPS call, and are never
written to an event, exception, or result artifact.
"""
from __future__ import annotations

from dataclasses import dataclass
import fcntl
import json
import math
import os
from pathlib import Path
import time
import uuid
from typing import Any
from urllib import error, request
from urllib.parse import urlparse

from .core import CostLedger, HarnessError, MODEL_IDS, atomic_write_json, canonical_json_bytes

OPENROUTER_CHAT_URL = "https://openrouter.ai/api/v1/chat/completions"


class OpenRouterError(HarnessError):
    """A transport or provider-contract error with no credential material."""


class UnknownRequestOutcome(OpenRouterError):
    """The request may have reached the provider; its reservation is retained."""


@dataclass(frozen=True)
class Completion:
    request_id: str
    model: str | None
    provider: Any
    usage: dict[str, Any]
    cost_usd: float
    generation_id: str | None
    message: dict[str, Any]
    raw_response: dict[str, Any]


def _finite_nonnegative(value: Any, field: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(value) or value < 0:
        raise OpenRouterError(f"{field} must be a finite non-negative number")
    return float(value)


def worst_case_cost_usd(model: dict[str, Any], *, max_input_tokens: int, max_output_tokens: int) -> float:
    """Calculate a conservative configured maximum using pinned price fields."""
    if not isinstance(max_input_tokens, int) or max_input_tokens <= 0:
        raise OpenRouterError("max_input_tokens must be a positive integer")
    if not isinstance(max_output_tokens, int) or max_output_tokens <= 0:
        raise OpenRouterError("max_output_tokens must be a positive integer")
    prices = model.get("prices") if isinstance(model, dict) else None
    if not isinstance(prices, dict):
        raise OpenRouterError("Pinned model prices are required")
    input_rate = _finite_nonnegative(prices.get("input_per_million_usd"), "input_per_million_usd")
    output_rate = _finite_nonnegative(prices.get("output_per_million_usd"), "output_per_million_usd")
    if input_rate <= 0 or output_rate <= 0:
        raise OpenRouterError("Pinned model prices must be positive")
    return (max_input_tokens * input_rate + max_output_tokens * output_rate) / 1_000_000


def _append_event(path: Path, event: dict[str, Any]) -> None:
    """Append a small JSONL audit event under an advisory lock, never including headers."""
    path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = path.with_suffix(path.suffix + ".lock")
    lock_path.touch(exist_ok=True)
    with lock_path.open("r+", encoding="utf-8") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            with path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")
                handle.flush()
                os.fsync(handle.fileno())
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


class OpenRouterClient:
    """One exact-model OpenRouter client for author, reviewer, and adjudicator turns."""

    def __init__(
        self,
        *,
        ledger: CostLedger,
        event_path: Path,
        model_prices: dict[str, dict[str, Any]],
        api_key_env: str = "OPENROUTER_API_KEY",
        endpoint: str = OPENROUTER_CHAT_URL,
        timeout_seconds: int = 120,
    ) -> None:
        if not isinstance(api_key_env, str) or not api_key_env or not api_key_env.replace("_", "a").isalnum():
            raise OpenRouterError("api_key_env must be a simple environment variable name")
        parsed = urlparse(endpoint)
        if endpoint != OPENROUTER_CHAT_URL or parsed.scheme != "https" or parsed.netloc != "openrouter.ai":
            raise OpenRouterError("Only the pinned HTTPS OpenRouter chat-completions endpoint is permitted")
        if not isinstance(timeout_seconds, int) or not 1 <= timeout_seconds <= 600:
            raise OpenRouterError("OpenRouter timeout_seconds must be an integer from 1 to 600")
        if not model_prices or not set(model_prices).issubset(set(MODEL_IDS)):
            raise OpenRouterError("Model price table must be a non-empty subset of the pinned model IDs")
        self.ledger = ledger
        self.event_path = event_path
        self.model_prices = model_prices
        self.api_key_env = api_key_env
        self.endpoint = endpoint
        self.timeout_seconds = timeout_seconds

    @staticmethod
    def _request_payload(
        *, model_id: str, messages: list[dict[str, Any]], tools: list[dict[str, Any]],
        max_output_tokens: int, response_format: dict[str, Any] | None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": model_id,
            "messages": messages,
            "tools": tools,
            "tool_choice": "auto" if tools else "none",
            "plugins": [],
            "provider": {
                "order": [model_id.split("/", 1)[0]],
                "require_parameters": True,
                "allow_fallbacks": False,
            },
            "max_tokens": max_output_tokens,
        }
        if response_format is not None:
            payload["response_format"] = response_format
        return payload

    def serialized_request_size_bytes(
        self, *, model_id: str, messages: list[dict[str, Any]], tools: list[dict[str, Any]],
        max_output_tokens: int, response_format: dict[str, Any] | None = None,
    ) -> int:
        """Return exact wire-body size without reserving cost or making a request."""
        payload = self._request_payload(
            model_id=model_id, messages=messages, tools=tools,
            max_output_tokens=max_output_tokens, response_format=response_format,
        )
        return len(canonical_json_bytes(payload))

    def complete(
        self,
        *,
        model_id: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]],
        max_input_tokens: int,
        max_output_tokens: int,
        max_request_bytes: int | None = None,
        response_format: dict[str, Any] | None = None,
        audit: dict[str, Any],
    ) -> Completion:
        """Reserve before a request, call exactly one selected model, then settle safely.

        If a network/HTTP/format failure leaves billing unknown, the reservation is
        deliberately retained.  This is conservative: later calls cannot spend
        money that might already have been charged.
        """
        if model_id not in self.model_prices:
            raise OpenRouterError("Attempted model is not one of the exact selected IDs")
        if not isinstance(messages, list) or not messages or not all(isinstance(item, dict) for item in messages):
            raise OpenRouterError("messages must be a non-empty object array")
        if not isinstance(tools, list) or not all(isinstance(item, dict) for item in tools):
            raise OpenRouterError("tools must be an object array")
        if response_format is not None and (
            not isinstance(response_format, dict)
            or response_format.get("type") != "json_schema"
            or not isinstance(response_format.get("json_schema"), dict)
        ):
            raise OpenRouterError("response_format must be a JSON Schema structured-output contract")
        estimate = worst_case_cost_usd(
            self.model_prices[model_id], max_input_tokens=max_input_tokens, max_output_tokens=max_output_tokens
        )
        request_id = uuid.uuid4().hex
        if max_request_bytes is None:
            max_request_bytes = max_input_tokens
        if not isinstance(max_request_bytes, int) or isinstance(max_request_bytes, bool) or max_request_bytes <= 0:
            raise OpenRouterError("max_request_bytes must be a positive integer")
        payload = self._request_payload(
            model_id=model_id, messages=messages, tools=tools,
            max_output_tokens=max_output_tokens, response_format=response_format,
        )
        body = canonical_json_bytes(payload)
        # Token allowance drives price reservations; this independent hard byte
        # limit bounds the serialized HTTP body. Both are checked before reserve/network.
        if len(body) > max_request_bytes:
            raise OpenRouterError(
                f"Serialized request is {len(body)} bytes, exceeding max_request_bytes={max_request_bytes}; no API request was sent"
            )
        safe_audit = {
            key: value for key, value in audit.items()
            if key in {"issue_id", "stage", "role", "turn", "replicate", "author_model", "reviewer_model"}
        }
        self.ledger.reserve(request_id, estimate, {"model": model_id, **safe_audit})
        event_base = {"at": time.time(), "request_id": request_id, "requested_model": model_id, "reserved_usd": estimate, **safe_audit}
        # The only environment read of the credential occurs here, at call time.
        api_key = os.environ.get(self.api_key_env)
        if not api_key:
            self.ledger.cancel(request_id, "credential_missing_before_request")
            raise OpenRouterError(f"Required API-key environment variable {self.api_key_env} is not set")
        req = request.Request(
            self.endpoint,
            data=body,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json", "Accept": "application/json"},
            method="POST",
        )
        try:
            with request.urlopen(req, timeout=self.timeout_seconds) as response:
                raw_bytes = response.read()
        except error.HTTPError as exc:
            # Even an HTTP error can follow provider-side generation.  Preserve
            # its reservation instead of assuming a zero bill.
            _append_event(self.event_path, {**event_base, "event": "unknown_http_outcome", "http_status": exc.code})
            raise UnknownRequestOutcome(f"OpenRouter returned HTTP {exc.code}; reservation retained") from None
        except (error.URLError, TimeoutError, OSError) as exc:
            _append_event(self.event_path, {**event_base, "event": "unknown_transport_outcome", "error_type": type(exc).__name__})
            raise UnknownRequestOutcome("OpenRouter request outcome is unknown; reservation retained") from None
        try:
            decoded = json.loads(raw_bytes.decode("utf-8"))
            if not isinstance(decoded, dict):
                raise ValueError("response root is not an object")
            usage = decoded.get("usage")
            if not isinstance(usage, dict):
                raise ValueError("response usage is absent")
            cost = _finite_nonnegative(usage.get("cost"), "response usage.cost")
            choices = decoded.get("choices")
            if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
                raise ValueError("response choices[0] is absent")
            message = choices[0].get("message")
            if not isinstance(message, dict):
                raise ValueError("response choices[0].message is absent")
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError, OpenRouterError) as exc:
            _append_event(self.event_path, {**event_base, "event": "unknown_response_format", "error_type": type(exc).__name__})
            raise UnknownRequestOutcome("OpenRouter response cannot be safely cost-accounted; reservation retained") from None
        returned_model = decoded.get("model") if isinstance(decoded.get("model"), str) else None
        provider = decoded.get("provider")
        generation_id = decoded.get("generation_id") or decoded.get("id")
        generation_id = generation_id if isinstance(generation_id, str) else None
        audit_event = {
            **event_base,
            "event": "settled_response",
            "returned_model": returned_model,
            "provider": provider,
            "usage": usage,
            "cost_usd": cost,
            "generation_id": generation_id,
        }
        _append_event(self.event_path, audit_event)
        # A returned model mismatch is a protocol failure, but settle its known
        # bill first so accounting remains truthful.
        self.ledger.settle(request_id, cost)
        if returned_model != model_id:
            raise OpenRouterError(
                f"OpenRouter returned model {returned_model!r}, not the requested exact model {model_id!r}"
            )
        return Completion(
            request_id=request_id,
            model=returned_model,
            provider=provider,
            usage=usage,
            cost_usd=cost,
            generation_id=generation_id,
            message=message,
            raw_response=decoded,
        )


def write_request_contract(path: Path, model_ids: list[str] | tuple[str, ...] = MODEL_IDS) -> None:
    """Write the fixed non-secret transport contract for provenance inspection."""
    atomic_write_json(path, {
        "endpoint": OPENROUTER_CHAT_URL,
        "tool_choice": "auto_when_tools_supplied_else_none",
        "plugins": [],
        "provider": {
            "order": "first-party provider slug from each exact model ID",
            "require_parameters": True,
            "allow_fallbacks": False,
        },
        "structured_output": {
            "roles": ["review", "adjudicate"],
            "parameter": "response_format.type=json_schema",
            "unsupported_endpoint_policy": "provider_error; no fallback",
            "max_findings": 10,
            "max_items_wire_schema": False,
            "max_items_enforcement": "strict local validation; reject, never truncate",
        },
        "models": list(model_ids),
        "credential_policy": "read_only_at_explicit_call_time_from_environment; never_logged",
        "input_guards": {
            "priced_allowance": "max_input_tokens; used to reserve cost",
            "wire_body_limit": "max_request_bytes; UTF-8 serialized HTTP payload bytes, checked before reservation/network",
        },
    })
