"""Bubblewrap isolation and local tools exposed to model agents.

No tool accesses the host source/evaluator root.  All filesystem access is
constrained to the per-instance workspace, and shell commands run in an
unprivileged network-less bubblewrap container.
"""
from __future__ import annotations

import json
import os
import selectors
import shutil
import subprocess
import time
from pathlib import Path, PurePosixPath
from typing import Any

from .core import (
    HarnessError,
    assert_workspace_hygiene,
    runtime_environment,
    runtime_overlay_paths,
    safe_workspace_path,
)

SYSTEM_BIND_CANDIDATES = ("/usr", "/bin", "/lib", "/lib64")
SYSTEM_CONFIG_CANDIDATES = ("/etc/ld.so.cache", "/etc/nsswitch.conf", "/etc/passwd", "/etc/group")


def build_bwrap_command(
    *,
    workspace: Path,
    dependencies: dict[str, Path] | None = None,
    writable_workspace: bool,
    program: list[str],
    evaluator_root: Path | None = None,
    output_dir: Path | None = None,
    runtime: dict[str, Any] | None = None,
    private_evaluator_workspace: bool = False,
    allowed_internal_relative_symlinks: dict[str, str] | None = None,
    allow_synthetic_git: bool = False,
) -> list[str]:
    """Build an explicit no-host-root bubblewrap command.

    The agent variant has no evaluator_root/output_dir. The evaluator may use a
    writable *private copy* of the agent workspace, never the agent workspace
    itself; callers must opt into that exceptional mode explicitly.
    """
    if not program:
        raise HarnessError("Sandbox program cannot be empty")
    if shutil.which("bwrap") is None or not Path("/usr/bin/bwrap").is_file():
        raise HarnessError("Bubblewrap is required but /usr/bin/bwrap is unavailable")
    if workspace.is_symlink():
        raise HarnessError("Workspace root may not be a symlink")
    workspace = workspace.resolve(strict=True)
    if not workspace.is_dir():
        raise HarnessError("Workspace must be a directory")
    # A source copy is scrubbed before first use; checking again here prevents
    # a previous agent turn from introducing .git, harness metadata, or a link
    # before any subsequent shell/evaluator mount is assembled.
    assert_workspace_hygiene(
        workspace,
        allowed_internal_relative_symlinks=allowed_internal_relative_symlinks,
        allow_synthetic_git=allow_synthetic_git,
    )
    if dependencies is None:
        dependencies = {}
    if evaluator_root is not None and writable_workspace and not private_evaluator_workspace:
        raise HarnessError("Evaluator sandbox may write only an explicitly private workspace copy")
    if private_evaluator_workspace and evaluator_root is None:
        raise HarnessError("A private evaluator workspace requires an evaluator root")
    if output_dir is not None and evaluator_root is None:
        raise HarnessError("A writable output directory is reserved for evaluator execution")
    sandbox_env = runtime_environment(runtime)
    command = [
        "/usr/bin/bwrap",
        "--die-with-parent",
        "--new-session",
        "--unshare-user",
        "--unshare-pid",
        "--unshare-ipc",
        "--unshare-uts",
        "--unshare-cgroup",
        "--unshare-net",
        "--uid", "65534",
        "--gid", "65534",
        "--clearenv",
        "--proc", "/proc",
        "--dev", "/dev",
        "--tmpfs", "/tmp",
        "--dir", "/etc",
        "--dir", "/workspace",
        "--dir", "/deps",
    ]
    for key, value in sorted(sandbox_env.items()):
        command += ["--setenv", key, value]
    # Bind listed library/system roots only.  In particular, never bind '/'.
    for source in SYSTEM_BIND_CANDIDATES:
        if Path(source).exists():
            command += ["--ro-bind", source, source]
    # Minimal selected runtime configuration; no host /etc, home, resolver or credentials.
    for source in SYSTEM_CONFIG_CANDIDATES:
        if Path(source).is_file():
            command += ["--ro-bind", source, source]
    command += (["--bind", str(workspace), "/workspace"] if writable_workspace else ["--ro-bind", str(workspace), "/workspace"])
    for name, path in sorted(dependencies.items()):
        if not name or "/" in name or ".." in name:
            raise HarnessError(f"Unsafe dependency name: {name!r}")
        if path.is_symlink():
            raise HarnessError(f"Dependency root may not be a symlink: {name}")
        source = path.resolve(strict=True)
        command += ["--dir", f"/deps/{name}", "--ro-bind", str(source), f"/deps/{name}"]
    if runtime and runtime.get("language") is not None:
        overlays = runtime.get("overlays")
        if not isinstance(overlays, list):
            raise HarnessError("Runtime overlays are malformed")
        for overlay in overlays:
            if not isinstance(overlay, dict) or not isinstance(overlay.get("dependency"), str):
                raise HarnessError("Runtime overlay is malformed")
            name = overlay["dependency"]
            if name not in dependencies:
                raise HarnessError(f"Runtime overlay dependency is not staged: {name}")
            workspace_path = overlay.get("workspace_path")
            if workspace_path not in runtime_overlay_paths(runtime):
                raise HarnessError("Runtime overlay workspace path is malformed")
            target = workspace.joinpath(*Path(workspace_path).parts)
            if target.is_symlink() or not target.is_dir():
                raise HarnessError(f"Runtime overlay mount point is not a directory: {workspace_path}")
            root = dependencies[name].resolve(strict=True)
            subpath = overlay.get("source_subpath", ".")
            source = root if subpath == "." else root.joinpath(*PurePosixPath(subpath).parts)
            if source.is_symlink() or not source.is_dir():
                raise HarnessError(f"Runtime overlay source must be an existing non-symlink directory: {name}/{subpath}")
            try:
                source.resolve(strict=True).relative_to(root)
            except ValueError as exc:
                raise HarnessError(f"Runtime overlay source escapes its dependency tree: {name}/{subpath}") from exc
            command += ["--ro-bind", str(source), "/workspace/" + workspace_path]
    if evaluator_root is not None:
        if evaluator_root.is_symlink():
            raise HarnessError("Evaluator root may not be a symlink")
        evaluator_root = evaluator_root.resolve(strict=True)
        command += ["--dir", "/evaluator", "--ro-bind", str(evaluator_root), "/evaluator"]
    if output_dir is not None:
        if output_dir.is_symlink():
            raise HarnessError("Evaluator output root may not be a symlink")
        output_dir = output_dir.resolve(strict=True)
        command += ["--dir", "/output", "--bind", str(output_dir), "/output"]
    return command + ["--chdir", "/workspace", "--"] + program


def bounded_text(value: str, limit: int) -> str:
    if len(value) <= limit:
        return value
    return value[:limit] + f"\n...[truncated {len(value) - limit} characters]"


def run_bounded_process(command: list[str], *, timeout_seconds: int, output_chars: int, env: dict[str, str]) -> dict[str, Any]:
    """Run a command while draining pipes but retaining only bounded output.

    ``subprocess.run(..., PIPE)`` is intentionally avoided: an adversarial
    command could otherwise make the host retain an unbounded stdout/stderr
    buffer before ToolRunner truncates the result.
    """
    process = subprocess.Popen(
        command,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd="/",
        env=env,
    )
    if process.stdout is None or process.stderr is None:  # defensive; Popen above requests both
        process.kill()
        raise HarnessError("Sandbox process pipes were not configured")
    selector = selectors.DefaultSelector()
    selector.register(process.stdout, selectors.EVENT_READ, "stdout")
    selector.register(process.stderr, selectors.EVENT_READ, "stderr")
    retained: dict[str, bytearray] = {"stdout": bytearray(), "stderr": bytearray()}
    dropped: dict[str, bool] = {"stdout": False, "stderr": False}
    byte_limit = output_chars * 4 + 4096
    deadline = time.monotonic() + timeout_seconds
    timed_out = False
    while selector.get_map():
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            if not timed_out:
                timed_out = True
                process.kill()
            remaining = 1.0
        for key, _ in selector.select(max(0.0, remaining)):
            stream = key.fileobj
            chunk = os.read(stream.fileno(), 65536)
            if not chunk:
                selector.unregister(stream)
                continue
            bucket = retained[key.data]
            available = byte_limit - len(bucket)
            if available > 0:
                bucket.extend(chunk[:available])
            if len(chunk) > max(available, 0):
                dropped[key.data] = True
    selector.close()
    try:
        returncode = process.wait(timeout=2)
    except subprocess.TimeoutExpired:
        process.kill()
        returncode = process.wait(timeout=2)

    def render(name: str) -> str:
        value = bounded_text(bytes(retained[name]).decode("utf-8", "replace"), output_chars)
        return value + ("\n...[truncated at sandbox capture limit]" if dropped[name] else "")

    return {"returncode": returncode, "stdout": render("stdout"), "stderr": render("stderr"), "timeout": timed_out}


class ToolRunner:
    """The only local capability granted to a model during a stage."""

    def __init__(
        self,
        workspace: Path,
        dependencies: dict[str, Path],
        log_path: Path,
        *,
        writable: bool,
        limits: dict[str, Any],
        max_commands: int,
        runtime: dict[str, Any] | None = None,
        allowed_internal_relative_symlinks: dict[str, str] | None = None,
        allow_synthetic_git: bool = False,
    ) -> None:
        self.workspace = workspace.resolve(strict=True)
        self.dependencies = dependencies
        self.log_path = log_path
        self.writable = writable
        self.output_chars = int(limits.get("output_chars", 8000))
        self.read_bytes = int(limits.get("read_bytes", 24000))
        self.write_bytes = int(limits.get("write_bytes", 100000))
        self.shell_timeout = int(limits.get("shell_timeout_seconds", 60))
        self.max_commands = max_commands
        self.runtime = runtime
        self.allowed_internal_relative_symlinks = allowed_internal_relative_symlinks
        self.allow_synthetic_git = allow_synthetic_git
        self.runtime_overlays = runtime_overlay_paths(runtime)
        self.commands_used = 0
        self.log_path.parent.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def schemas(writable: bool) -> list[dict[str, Any]]:
        tools = [
            {"type": "function", "function": {"name": "read", "description": "Read a UTF-8 workspace file using a safe relative path.", "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"], "additionalProperties": False}}},
            {"type": "function", "function": {"name": "list", "description": "List a workspace directory using a safe relative path (use '.' for root).", "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "depth": {"type": "integer"}}, "required": ["path"], "additionalProperties": False}}},
            {"type": "function", "function": {"name": "search", "description": "Find a literal text string in workspace regular files.", "parameters": {"type": "object", "properties": {"query": {"type": "string"}, "path": {"type": "string"}}, "required": ["query"], "additionalProperties": False}}},
            {"type": "function", "function": {"name": "shell", "description": "Run a shell command inside the isolated /workspace sandbox; network is unavailable.", "parameters": {"type": "object", "properties": {"command": {"type": "string"}, "timeout_seconds": {"type": "integer"}}, "required": ["command"], "additionalProperties": False}}},
        ]
        if writable:
            tools.insert(3, {"type": "function", "function": {"name": "write", "description": "Create or replace a UTF-8 workspace file using a safe relative path.", "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "content": {"type": "string"}}, "required": ["path", "content"], "additionalProperties": False}}})
        return tools

    def _log(self, name: str, arguments: dict[str, Any], result: dict[str, Any], elapsed: float) -> None:
        # JSONL is deliberately bounded, including shell stdout/stderr and write content.
        event = {"at": time.time(), "tool": name, "request": arguments, "result": result, "elapsed_seconds": round(elapsed, 4)}
        with self.log_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")

    def run(self, name: str, arguments: dict[str, Any]) -> str:
        started = time.monotonic()
        result: dict[str, Any]
        safe_args = dict(arguments)
        if name == "write" and isinstance(safe_args.get("content"), str):
            safe_args["content"] = bounded_text(safe_args["content"], self.output_chars)
        try:
            if name == "read":
                result = self._read(arguments)
            elif name == "list":
                result = self._list(arguments)
            elif name == "search":
                result = self._search(arguments)
            elif name == "write":
                result = self._write(arguments)
            elif name == "shell":
                result = self._shell(arguments)
            else:
                result = {"ok": False, "error": f"Unknown tool: {name}"}
        except Exception as exc:  # Return safe error to model; never leak a host traceback.
            result = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
        result = self._bound_result(result)
        self._log(name, safe_args, result, time.monotonic() - started)
        return json.dumps(result, ensure_ascii=False, sort_keys=True)

    def _bound_result(self, result: dict[str, Any]) -> dict[str, Any]:
        encoded = json.dumps(result, ensure_ascii=False, sort_keys=True)
        if len(encoded) <= self.output_chars:
            return result
        return {"ok": result.get("ok", False), "truncated": True, "result": bounded_text(encoded, self.output_chars)}

    def _reject_runtime_overlay_path(self, requested: Any) -> None:
        """Host-side file tools must never see or alter a container-only overlay."""
        if not isinstance(requested, str):
            return
        candidate = Path(requested).as_posix()
        if candidate in {"", "."}:
            return
        for overlay in self.runtime_overlays:
            if candidate == overlay or candidate.startswith(overlay + "/"):
                raise HarnessError("Runtime overlays are read-only and available only to shell commands in /workspace")

    def _read(self, args: dict[str, Any]) -> dict[str, Any]:
        self._reject_runtime_overlay_path(args.get("path"))
        path = safe_workspace_path(self.workspace, args.get("path"))
        if not path.is_file():
            raise HarnessError("read path must be a regular file")
        with path.open("rb") as handle:
            data = handle.read(self.read_bytes + 1)
        if len(data) > self.read_bytes:
            data = data[:self.read_bytes]
            truncated = True
        else:
            truncated = False
        return {"ok": True, "path": args["path"], "content": data.decode("utf-8", errors="replace"), "truncated": truncated}

    def _list(self, args: dict[str, Any]) -> dict[str, Any]:
        requested = args.get("path")
        self._reject_runtime_overlay_path(requested)
        path = self.workspace if requested == "." else safe_workspace_path(self.workspace, requested)
        if not path.is_dir():
            raise HarnessError("list path must be a directory")
        depth = args.get("depth", 2)
        if not isinstance(depth, int) or not 0 <= depth <= 5:
            raise HarnessError("list depth must be an integer from 0 to 5")
        lines: list[str] = []
        base_depth = len(path.parts)
        for current, dirs, files in os.walk(path, topdown=True, followlinks=False):
            dirs.sort(); files.sort()
            current_path = Path(current)
            level = len(current_path.parts) - base_depth
            if level > depth:
                dirs[:] = []
                continue
            for item in dirs + files:
                candidate = current_path / item
                rel = candidate.relative_to(self.workspace).as_posix()
                if candidate.is_symlink():
                    marker = "@"
                else:
                    marker = "/" if candidate.is_dir() else ""
                lines.append(rel + marker)
                if len(lines) >= 500:
                    return {"ok": True, "entries": lines, "truncated": True}
        return {"ok": True, "entries": lines, "truncated": False}

    def _search(self, args: dict[str, Any]) -> dict[str, Any]:
        query = args.get("query")
        if not isinstance(query, str) or not query:
            raise HarnessError("search query must be a non-empty literal string")
        if len(query) > 1000:
            raise HarnessError("search query is too long")
        requested = args.get("path", ".")
        self._reject_runtime_overlay_path(requested)
        base = self.workspace if requested == "." else safe_workspace_path(self.workspace, requested)
        if not base.is_dir() and not base.is_file():
            raise HarnessError("search path must be a regular file or directory")
        candidates: list[Path] = [base] if base.is_file() else []
        if base.is_dir():
            for current, dirs, files in os.walk(base, topdown=True, followlinks=False):
                dirs[:] = [d for d in dirs if not (Path(current) / d).is_symlink()]
                candidates += [Path(current) / f for f in files if not (Path(current) / f).is_symlink()]
        matches: list[dict[str, Any]] = []
        for candidate in sorted(candidates):
            if not candidate.is_file() or candidate.stat().st_size > 2_000_000:
                continue
            try:
                lines = candidate.read_text(encoding="utf-8").splitlines()
            except UnicodeDecodeError:
                continue
            for number, line in enumerate(lines, start=1):
                if query in line:
                    matches.append({"path": candidate.relative_to(self.workspace).as_posix(), "line": number, "text": bounded_text(line, 500)})
                    if len(matches) >= 200:
                        return {"ok": True, "matches": matches, "truncated": True}
        return {"ok": True, "matches": matches, "truncated": False}

    def _write(self, args: dict[str, Any]) -> dict[str, Any]:
        if not self.writable:
            raise HarnessError("write is not available in read-only review")
        content = args.get("content")
        if not isinstance(content, str):
            raise HarnessError("write content must be a string")
        raw = content.encode("utf-8")
        if len(raw) > self.write_bytes:
            raise HarnessError(f"write content exceeds {self.write_bytes} byte limit")
        self._reject_runtime_overlay_path(args.get("path"))
        path = safe_workspace_path(self.workspace, args.get("path"))
        path.parent.mkdir(parents=True, exist_ok=True)
        # safe_workspace_path checked each currently-existing prefix; ensure mkdir did not cross a link.
        path = safe_workspace_path(self.workspace, args.get("path"))
        flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, "O_NOFOLLOW", 0)
        descriptor = os.open(path, flags, 0o666)
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="") as handle:
            handle.write(content)
        return {"ok": True, "path": args["path"], "bytes_written": len(raw)}

    def _shell(self, args: dict[str, Any]) -> dict[str, Any]:
        command = args.get("command")
        if not isinstance(command, str) or not command.strip() or len(command) > 8000:
            raise HarnessError("shell command must be a non-empty string up to 8000 characters")
        if self.commands_used >= self.max_commands:
            raise HarnessError("stage shell command limit reached")
        requested_timeout = args.get("timeout_seconds", self.shell_timeout)
        if not isinstance(requested_timeout, int) or requested_timeout <= 0:
            raise HarnessError("shell timeout_seconds must be positive integer")
        timeout = min(requested_timeout, self.shell_timeout)
        self.commands_used += 1
        bwrap = build_bwrap_command(
            workspace=self.workspace,
            dependencies=self.dependencies,
            writable_workspace=self.writable,
            program=["/bin/sh", "-lc", command],
            runtime=self.runtime,
            allowed_internal_relative_symlinks=self.allowed_internal_relative_symlinks,
            allow_synthetic_git=self.allow_synthetic_git,
        )
        captured = run_bounded_process(
            bwrap,
            timeout_seconds=timeout,
            output_chars=self.output_chars,
            env={"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": "/nonexistent", "LANG": "C.UTF-8"},
        )
        return {"ok": captured["returncode"] == 0 and not captured["timeout"], **captured}
