# Autonomous code-review benchmark manuscript

The manuscript is in English; discussion and project notes remain in Russian. The main source is `arkheion-project/main.typ`, with its bibliography and figure beside it. The revision clarifies that five incomplete workflows had an initial evaluator run whose result was not persisted, while three terminated before initial evaluation; it does not impute the missing values. It also adds descriptive results by task-input form and labels the degenerate uplift bootstrap as diagnostic-only. Appendix B summarizes task input forms and previously archived C0/historical-fix checks. The public content-reduced release is at <https://github.com/AdamShakhabov/autonomous-code-review-study>. The PDF carries Adam Shakhabov's name and email, but it is not submitted to or accepted by arXiv. The title block intentionally omits a “Working draft” label and a date.

## Build

From `arkheion-project/` run:

```sh
typst compile main.typ main.pdf
```

Typst fetches the pinned Arkheion 0.1.2 package. `figure1_workflow.mmd` at the parent folder is the editable source for the included rendered PNG.

## Before any submission

Before submission, confirm any desired affiliation; recheck the then-current arXiv PDF submission rules; choose categories; and verify all repository licenses and task links. The manuscript deliberately does not claim that human PR review is ineffective or that PRs are obsolete.
