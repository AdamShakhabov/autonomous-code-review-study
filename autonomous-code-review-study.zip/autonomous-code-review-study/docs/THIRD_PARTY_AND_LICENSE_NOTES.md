# Third-party and license notes

## Upstream repositories

The task corpus references public issues and pull requests from ABP Framework, Kiota, Directus, Strapi, and Wagtail. Their source snapshots, hidden evaluator assets, dependency caches, and patches are **not** included in this repository. Follow the links in `config/corpus_manifest_public.json` to review the applicable upstream licenses and histories.

## Study-authored materials

The proposed public repository contains study-authored documentation, aggregate/result metadata, configuration, and harness code. Before publication, the repository owner should choose a license for these materials. A practical default is the MIT License for code and a separate CC BY 4.0 license for documentation and aggregated data, but this release deliberately does not select either without the owner’s explicit decision.

## Data limitations

The public 48-row outcome dataset is a content-reduced derivative of private run records. It contains no evaluator source, raw model content, or upstream code. It supports reanalysis of reported counts, but does not grant access to the private hidden oracle or make the full benchmark independently executable.
