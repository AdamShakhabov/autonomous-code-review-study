# Reproducibility and verification

The public archive is hosted at [github.com/AdamShakhabov/autonomous-code-review-study](https://github.com/AdamShakhabov/autonomous-code-review-study).

## What this public release supports

This release supports **audit and reanalysis of the published matrix-level results**, not independent end-to-end reruns of the benchmark.

The release contains 48 workflow rows, 12 task/provenance rows, 564 stripped API-event rows, and five stripped unresolved-reservation rows. The tables retain only identifiers, categorical outcomes, coarse termination codes, numerical operational counters, and costs. They deliberately omit evaluator logs, model outputs, patches, request/generation IDs, and hidden tests.

Run:

```bash
python3 scripts/reproduce_paper_tables.py \
  --data data \
  --output derived/paper_numbers.json \
  --check expected/paper_numbers.json
```

The command makes no network calls and requires only Python 3 standard library modules. It validates the rectangular matrix; reproduces planned and completed denominators, paired transitions, pair and issue summaries, termination classes, outcomes stratified by input form, context-compaction counters, and stripped API/accounting totals. It marks five post-initial-evaluation results as unpersisted and three author-stage cases as not evaluated, so it does not fabricate a full-planned initial pass rate. It recalculates the fixed 2,000-sample, seed-20261022 issue-cluster bootstrap intervals; the degenerate completed-case uplift interval is labelled diagnostic-only, not as a population-effect uncertainty interval. The output is compared against `expected/paper_numbers.json`.

## Why the benchmark cannot be rerun from this release alone

The original study protected its oracle by withholding evaluator assets from the coding agents. This public release continues that protection. It also does not redistribute source snapshots, third-party package caches, raw model/API records, or model-generated diffs. Those exclusions prevent exposure of test answers and avoid redistributing third-party repository material outside its upstream context.

The public task manifest provides immutable C0 commit IDs, source-tree hashes, public issue and PR links, input-policy metadata, and task-text hashes. It enables provenance audit, but not reconstruction of an isolated evaluator environment. Any future full replication package would require a separate license review, a new held-out task corpus, and an explicit policy for controlled evaluator access.

## Integrity anchors

The following original study hashes are retained for cross-reference:

- Frozen corpus manifest: `1c6f6cc850ea69afb34d1b8fe2e6feff7da47a399a6a389613431764b37fd3f6`
- Raw private `results.json`: `0ebb7c6a0f1db97ccecbae6c0015aa013f6c0675f92c39628e1a3981dab847cd`
- Private frozen `analysis_v8.json`: `87ea4bfffa674e9f7eff5e69a4bea575692aa2ecf2c28f7220e32cdcf13596a7`

The raw-results hash identifies a private source artifact. The analysis hash identifies the original aggregate record retained in this package. These hashes anchor file identity; they do not independently validate hidden-test labels. The content-reduced workflow table is a documented derivative and now distinguishes outcomes that were not preserved from evaluations that never ran.
