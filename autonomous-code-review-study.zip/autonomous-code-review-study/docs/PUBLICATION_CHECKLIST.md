# Publication record and remaining checks

Canonical public repository: <https://github.com/AdamShakhabov/autonomous-code-review-study>.

## Completed

- [x] Created the public GitHub repository under AdamShakhabov.
- [x] Published the content-reduced reproducibility package as `autonomous-code-review-study.zip` on the `main` branch.
- [x] Published a root README linking to the archive and describing its scope and licenses.
- [x] Applied MIT to study-authored code and CC BY 4.0 to study-authored documentation, data, and manuscript assets.
- [x] Added the canonical repository URL to the manuscript's Data and Code Availability statement and rebuilt/validated the PDF.
- [x] Retained explicit exclusions for hidden evaluators, third-party source snapshots, raw model/API records, patches, and credentials.

## Before any arXiv submission

- [ ] Recheck the then-current arXiv submission requirements and select appropriate subject categories.
- [ ] Review the manuscript and public repository together, including citation metadata, issue links, and license scope.
- [ ] Consider creating an immutable GitHub Release and/or Zenodo archive. No DOI is claimed or created by this checklist.
