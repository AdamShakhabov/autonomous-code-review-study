# Publication checklist

This checklist describes the intended first public release at:

`https://github.com/AdamShakhabov/autonomous-code-review-study`

## Completed locally

- [x] Created content-reduced workflow, task/provenance, operational, and accounting tables.
- [x] Reproduced headline counts, paired transitions, bootstrap intervals, termination/compaction totals, and accounting totals without network, model calls, or hidden-test execution.
- [x] Included study-authored harness/analysis source and frozen, credential-free configuration summaries.
- [x] Excluded hidden evaluator source/commands, source snapshots, dependency caches, raw API records, raw model transcripts, patches/diffs, and credentials.
- [x] Checked staged files for high-confidence credential patterns and environment-specific absolute paths.
- [x] Confirmed that the intended GitHub repository name was unclaimed at the time of preparation.

## Owner decisions confirmed before public push

- [x] The GitHub repository is authorized to be **public**.
- [x] Study-authored code uses MIT; study-authored documentation/data/manuscript assets use CC BY 4.0. See `LICENSES.md`.
- [x] The first commit contents were confirmed as listed in the root README and `docs/ARTIFACT_SCOPE.md`.

## Actions after publication

1. Create the public GitHub repository and push the audited staging tree.
2. Verify that the public README, data files, manuscript PDF, and citation file are reachable at the canonical URL.
3. Add the exact public repository URL to the manuscript's data-and-code availability statement, rebuild the PDF, and re-run PDF validation.
4. Optionally create an immutable GitHub Release and/or a Zenodo archive. A Zenodo DOI is not created by this checklist.
