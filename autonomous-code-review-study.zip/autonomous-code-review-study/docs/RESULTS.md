# Results summary

## Matrix completion and incomplete initial outcomes

The matrix contains 48 planned workflow keys and 48 unique durable records. Forty workflows completed with final evaluator outcomes; eight terminated before a complete outcome. In five reviewer/adjudicator-stage terminations, the initial hidden evaluator had run but its result was not preserved in the termination record or run directory. Three other terminations happened in the author stage before initial evaluation. Thus the initial result is available for the 40 completed workflows, unavailable-but-evaluated for five, and not evaluated for three. The full-planned initial pass rate cannot be recovered; the five missing outcomes are not recoded as failures.

| Author → reviewer | Planned | Completed | Initial pass among completed | Final pass among completed | Final pass / planned |
|---|---:|---:|---:|---:|---:|
| OpenAI → Anthropic | 24 | 18 | 0/18 | 0/18 | 0/24 |
| Anthropic → OpenAI | 24 | 22 | 4/22 | 4/22 | 4/24 |
| Total | 48 | 40 | 4/40 | 4/40 | 4/48 |

## Paired outcome change among completed workflows

| Initial outcome | Final pass | Final fail | Total |
|---|---:|---:|---:|
| Pass | 4 | 0 | 4 |
| Fail | 0 | 36 | 36 |
| Total | 4 | 36 | 40 |

No completed workflow changed hidden-test pass/fail status between the initial author patch and the final patch after review/adjudication. The observed completed-workflow uplift was 0 percentage points. This is a finding about the 40 observed pairs only, not proof of a zero effect in a broader task population.

The operational planned-matrix final pass rate was 4/48 (8.3%), counting incomplete workflows as not-pass for that final outcome metric. The completed-workflow final pass rate was 4/40 (10.0%). The issue-weighted planned-matrix final pass rate was 8.3%; its issue-cluster bootstrap interval was 0.0%–20.8%. Two of 12 tasks had at least one passing workflow (16.7%). The bootstrap procedure's [0, 0] interval for completed-case uplift is retained only as a diagnostic of the zero observed within-issue transitions; it is not an informative uncertainty interval for a population effect.

## Outcomes by input form

| Frozen task input | Tasks | Planned | Completed | Final pass / planned | Final pass / completed |
|---|---:|---:|---:|---:|---:|
| Title only | 9 | 36 | 30 | 0/36 | 0/30 |
| Bounded current issue snapshot | 3 | 12 | 10 | 4/12 | 4/10 |

All four passes came from the three tasks with a bounded current issue snapshot. This is a post hoc descriptive association, not evidence that adding issue text caused success: task identity is confounded with input form, and completion rates differ between groups.

## Interpretation and operational costs

These findings describe one small, prior-exposed corpus and one specified autonomous workflow. They do not establish that the true review effect is exactly zero, that review comments were useless, that a human pre-merge review would behave similarly, or that pull requests should be removed.

Five terminations arose from structured-output validation, two from unknown transport outcomes, and one from an external execution interruption. Terminations were asymmetric by provider direction. The reported matrix had 562 settled responses and two unknown transport events; settled matrix API cost was $4.072381, with $10.181374 cumulative lifetime actual spend against the $50 cap and $0.1765 in open reservations at close.
