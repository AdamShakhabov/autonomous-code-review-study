# Results summary

## Matrix completion

The matrix contains 48 planned workflow keys and 48 unique durable records. Forty workflows completed with a final evaluator outcome; eight terminated before a complete evaluator outcome.

| Author → reviewer | Planned | Completed | Terminated | Initial pass | Final pass |
|---|---:|---:|---:|---:|---:|
| OpenAI → Anthropic | 24 | 18 | 6 | 0/24 | 0/24 |
| Anthropic → OpenAI | 24 | 22 | 2 | 4/24 | 4/24 |
| Total | 48 | 40 | 8 | 4/48 | 4/48 |

## Paired outcome change among completed workflows

| Initial outcome | Final pass | Final fail | Total |
|---|---:|---:|---:|
| Pass | 4 | 0 | 4 |
| Fail | 0 | 36 | 36 |
| Total | 4 | 36 | 40 |

No completed workflow changed hidden-test pass/fail status between the initial author patch and the final patch after review/adjudication. The observed completed-workflow uplift was 0 percentage points.

The operational full-matrix pass rate was 4/48 (8.3%), counting incomplete workflows as not-pass. The completed-workflow rate was 4/40 (10.0%). The issue-weighted mean planned-workflow pass rate was 8.3%; the frozen issue-cluster bootstrap interval was 0.0%–20.8%. Two of 12 tasks had at least one passing workflow (16.7%); no confidence interval is reported for that distinct incidence measure.

## Interpretation

These findings describe one small, prior-exposed corpus and one specified autonomous workflow. They do not establish that the true review effect is exactly zero, that review comments were useless, that a human pre-merge review would behave similarly, or that pull requests should be removed.

Five terminations arose from structured-output validation, two from unknown transport outcomes, and one from an external execution interruption. The 8/48 incomplete rate and directional asymmetry are material limitations.
