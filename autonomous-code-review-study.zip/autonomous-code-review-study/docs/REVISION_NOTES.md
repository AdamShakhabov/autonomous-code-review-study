# Post hoc analysis and manuscript revision

This revision responds to an independent critique of the manuscript and public artifact package. It changes only the interpretation, derived tables, and manuscript; it does not rerun models, evaluators, or the experiment.

## Corrections

1. **Incomplete initial outcomes.** Five workflows terminated during reviewer/adjudicator structured-output handling after initial evaluation had run, but the initial evaluator result was not preserved in the termination record or retained run artifacts. Three author-stage terminations occurred before initial evaluation. The public workflow table now distinguishes `initial_evaluator_ran_result_not_persisted` from `not_evaluated_before_initial_evaluation`. The missing pass/fail values are not imputed; the full-planned initial pass rate is unavailable. The 40 completed paired outcomes remain unchanged.
2. **Input-form stratification.** The public summary and manuscript now report that all four final passes occurred among the 12 planned workflows for the three tasks supplied with a bounded current issue snapshot; the title-only group had 0/36 planned passes. This is a post hoc descriptive association confounded by task identity and completion differences, not a causal estimate of prompt detail.
3. **Bootstrap interpretation.** The completed-case uplift bootstrap output `[0, 0]` is explicitly labeled diagnostic-only because every observed issue-level change is zero. It is not presented as evidence of zero population uncertainty or equivalence.
4. **Reproducibility boundary.** The manuscript and public documentation distinguish a reproducible numerical summary conditional on the released evaluator labels from independent validation of those labels. Hidden evaluators, raw patches, and trajectories remain excluded; hashes establish identity, not semantic validity.

## Unchanged experimental record

The planned matrix remains 48 workflows over 12 previously exposed tasks; 40 workflows have complete initial/final outcomes, with four pass-to-pass and 36 fail-to-fail transitions. Eight workflows terminated before a complete final outcome. No model API call or hidden evaluator was run to make this revision.
