# Public artifact scope

## Included

This release includes study-authored harness code, a frozen configuration without credentials, a content-reduced public task manifest, a 48-row workflow dataset, a 12-row task/provenance table, stripped operational/accounting tables, frozen aggregate analysis, English protocol/results documentation, and the manuscript source/PDF. All included result fields are either numerical, categorical, public provenance identifiers, or hashes.

## Excluded

The following artifacts are intentionally not published:

1. **Hidden evaluator files and commands.** Publishing them would disclose the evaluation oracle to future agents and can expose portions of upstream test code.
2. **C0 repository snapshots, dependency caches, and runtime overlays.** They are third-party source or binary distributions and require their own license and redistribution review.
3. **Raw API event logs, raw model responses, author/reviewer/adjudicator trajectories, tool logs, workspace state, patches, and diffs.** These can contain upstream source excerpts, issue text, test-related content, or provider request metadata beyond what is needed for the reported aggregate findings.
4. **Credentials and environment-specific files.** No OpenRouter, GitHub, or other credentials are included.

## Consequence

The release is suitable for computational reproduction of the reported descriptive numerical summaries conditional on the released evaluator-outcome labels, and for inspecting the study harness/configuration. In five terminated reviewer/adjudicator workflows, the initial evaluator had run but its result was not persisted; three other terminated workflows ended before initial evaluation. The released data marks these states separately and does not impute the missing pass/fail values. The initial outcomes for those five workflows cannot be recovered from the retained artifacts without running the evaluator again. The release is not sufficient to regenerate model outputs, independently execute the hidden evaluator, or validate oracle labels. The manuscript states these limitations explicitly.

## Third-party provenance

Each task points to an original public GitHub repository, issue, and resolving pull request in `config/corpus_manifest_public.json`. This release does not grant rights to third-party material. Use the linked upstream repositories for their applicable license notices and source history.
