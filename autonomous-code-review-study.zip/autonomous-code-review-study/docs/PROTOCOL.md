# Evaluated workflow protocol

## Design

The study used 12 historical GitHub issue contexts spanning C#, JavaScript, and Python. Each task was evaluated in two directed cross-provider configurations, with two replicates per configuration: OpenAI GPT-6.1-Sol as author with Anthropic Claude Sonnet 5.5 as reviewer, and the reverse direction. This produced 48 planned workflows.

The tasks and model contexts had appeared in earlier pilot runs. The matrix is therefore a **prior-exposed retrospective benchmark**, not an independent replication or a contamination-free holdout evaluation.

## Workflow

1. An author model inspected a C0 repository workspace and produced an initial patch through a bounded terminal-agent loop.
2. A cross-provider reviewer read a bounded rendering of the initial diff and emitted a JSON-Schema-constrained structured review.
3. The author model adjudicated findings and could revise the patch.
4. The same hidden evaluator independently assessed the initial and final patches.

The author stage allowed up to 12 tool-enabled model turns and a separate final turn. Reviewer and adjudicator structured output were capped at 800 completion tokens and at most 10 findings. The author completion cap was 400 tokens. Network access was disabled during agent and evaluator execution.

## Bounded context and synthetic Git

The terminal-agent workflow used a rolling bounded context. When a serialized request approached its byte cap, older completed tool exchanges were removed from model-visible history while the system prompt and original task stayed visible. Full trajectories remained in private audit logs. Each workspace contained an ephemeral local C0 Git baseline without a remote; Git auto-maintenance was disabled to avoid background cleanup races.

## Outcome and analysis

A pass required successful exit of the task-specific manifest evaluator. A completed workflow could therefore be pass or fail. A workflow that terminated before a complete evaluator outcome was recorded as incomplete and was not silently discarded.

The public outcome release preserves 48 rows and uses issue clusters, not individual model calls, as the unit for bootstrap resampling. The original frozen analysis used 2,000 issue-cluster resamples with seed `20261022` and a 95% percentile interval.

## Scope

The protocol evaluates a bundled post-author review/adjudication workflow. It does not separately identify reviewer quality, reviewer precision/recall, human review effects, pull-request policy effects, engineering time, or net engineering value.
