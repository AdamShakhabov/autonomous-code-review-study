# Autonomous Code Review: a prior-exposed retrospective benchmark

This repository accompanies the study **“When Does Autonomous Code Review Change Hidden-Test Outcomes? A Prior-Exposed Retrospective Benchmark.”** It provides an auditable public record of the reported V8 matrix, the harness implementation, frozen execution configuration, analysis code, paper source, and a compact 48-workflow outcome dataset.

## Main finding

Across 40 completed workflows in a 12-issue, prior-exposed retrospective benchmark, autonomous cross-provider review and adjudication produced **no observed initial-to-final changes** in hidden-test pass/fail status. Four completed workflows passed before review and also passed after review; 36 failed before and after review. Eight of 48 planned workflows terminated before a complete evaluator outcome and are retained in the public dataset.

This is a descriptive result for one bounded terminal-agent workflow and one fixed corpus. It does **not** establish equivalence, show that LLM review is useless, compare autonomous review with human pre-merge review, or demonstrate that pull requests are obsolete.

## Contents

- `data/v8_workflows.csv` — 48 content-reduced workflow rows with outcomes, termination codes, and per-workflow compaction counters.
- `data/tasks.csv` — 12 task/provenance rows with public identifiers, input forms, and archived C0/historical-fix validation codes.
- `data/api_events_sanitized.csv` and `data/reservations_sanitized.csv` — stripped numeric operational/accounting tables without request IDs or text payloads.
- `data/analysis_v8.json` and `data/v8_run_summary.json` — frozen aggregate analysis and public matrix/accounting summary.
- `config/corpus_manifest_public.json` — task identifiers, repository/issue/PR links, C0 commit IDs, input-policy metadata, and hashes; it excludes source snapshots and hidden evaluator assets.
- `config/execution_config_v8.json` — the frozen V8 configuration without credentials.
- `code/` — the Python harness components and analysis script used by the study.
- `scripts/reproduce_paper_tables.py` — standard-library reproduction of the published numerical tables and bootstrap intervals.
- `expected/paper_numbers.json` — golden output for the release verifier.
- `docs/` — protocol, results, scope, reproducibility, and third-party-content notes.
- `paper/` — the manuscript PDF and Typst source.

## Quick verification

No model API calls, repository clones, or hidden-test executions are needed to check the public summary:

```bash
python3 scripts/reproduce_paper_tables.py \
  --data data \
  --output derived/paper_numbers.json \
  --check expected/paper_numbers.json
```

The verifier checks the 48 unique issue × directed-pair × replicate rows, the 40/8 completion split, planned and completed pass rates, the paired transition table, directed-pair summaries, issue-weighted bootstrap intervals, termination classes, compaction counters, and stripped API/accounting totals. See [docs/REPRODUCIBILITY.md](docs/REPRODUCIBILITY.md).

## Deliberate exclusions

To avoid leaking the test oracle and to avoid redistributing third-party repository content, this repository excludes hidden evaluator source files and commands, C0 source snapshots, dependency caches, raw model transcripts, raw API events, tool traces, model-generated patches/diffs, and evaluator stdout/stderr. The stripped tables are sufficient to reproduce the paper's numerical summaries conditional on released evaluator-outcome labels, but they cannot independently re-execute or validate the end-to-end benchmark. Full limitations are documented in [docs/ARTIFACT_SCOPE.md](docs/ARTIFACT_SCOPE.md).

## Citation

Use the citation metadata in [`CITATION.cff`](CITATION.cff). The manuscript is a preprint draft and has not been submitted to or accepted by arXiv.

## License

Study-authored software in `code/` and `scripts/` is licensed under [MIT](LICENSE-CODE). Study-authored documentation, aggregate/content-reduced data, configuration summaries, manuscript source/PDF, figures, and metadata are licensed under [CC BY 4.0](LICENSE-DATA-DOCS.md). The package contains no third-party repository source code or hidden evaluator assets; original issue and pull-request links remain subject to their upstream repositories' terms and licenses.
