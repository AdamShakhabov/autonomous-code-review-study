# Security and disclosure policy

Do not commit credentials, access tokens, OpenRouter/GitHub configuration files, hidden evaluator assets, source snapshots, dependency caches, raw model transcripts, tool traces, or model-generated patches.

If you identify a potentially sensitive artifact in this repository, please do not open a public issue containing the content. Contact the repository owner at `theadamo86@gmail.com` with the file path and a minimal description.
