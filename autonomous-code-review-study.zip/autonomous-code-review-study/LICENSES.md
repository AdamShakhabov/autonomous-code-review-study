# License scope

Copyright © 2026 Adam Shakhabov.

- The study-authored Python software in `code/` and `scripts/` is licensed under the [MIT License](LICENSE-CODE).
- The study-authored documentation, aggregate/content-reduced data tables, configuration summaries, manuscript source/PDF, figures, and metadata are licensed under [Creative Commons Attribution 4.0 International](LICENSE-DATA-DOCS.md).
- No third-party repository source code, hidden evaluator source/assets, dependency caches, raw model output, or model-generated patches are distributed in this repository. Links to upstream issues and pull requests do not change the licenses or terms applicable to upstream material.

If you reuse material from this repository, retain applicable notices and provide attribution to Adam Shakhabov and this repository URL.
