# Public data dictionary

## `v8_workflows.csv` — 48 rows

Each row corresponds to one planned `(issue_id, author_model, reviewer_model, replicate)` workflow.

- `completion_status`: `completed` or `terminated_before_complete_workflow`.
- `initial_outcome`, `final_outcome`: `pass`, `fail`, or `not_evaluated_due_to_termination`.
- `termination_type` and `termination_detail_code`: content-reduced categories only; raw error messages are excluded.
- `author_turn_count`, `author_compacted_turn_count`, `dropped_tool_cycles`: numerical terminal-agent context counters.

## `tasks.csv` — 12 rows

This table records public task identity/provenance, C0 commit and source-tree hash, input-form metadata, prior-exposure label, and content-reduced archived C0/historical-fix validation status. It does not include raw issue bodies, source trees, evaluator commands, hidden test paths, or evaluator assets.

## `api_events_sanitized.csv` — 564 rows

One stripped API-event accounting row per original event. Request IDs, generation IDs, timestamps, token usage, prompts, responses, and error text are excluded. `settled_cost_usd` is present only for settled responses.

## `reservations_sanitized.csv` — 5 rows

One content-reduced unresolved-reservation row. Request IDs, timestamps, workflow identifiers, and diagnostic context are excluded. `origin` indicates whether the reservation predated V8 or arose in V8.

## Aggregate references

`analysis_v8.json` is the historical aggregate issue-cluster analysis. `v8_run_summary.json` records the public high-level result-integrity and API-accounting anchors. `expected/paper_numbers.json` is generated from the stripped tables by `scripts/reproduce_paper_tables.py`.
